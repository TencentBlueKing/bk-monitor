/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
import { defineComponent, nextTick, provide, type Ref, ref } from 'vue';

import useIntersectionObserver from '@/hooks/use-intersection-observer';

import './row-render.scss';

export default defineComponent({
  props: {
    rowIndex: {
      type: Number,
      default: 0,
    },
  },
  emits: ['row-click', 'row-visible', 'row-mousedown', 'row-mouseup', 'row-mouseenter', 'row-mouseleave'],
  setup(props, { slots, emit }) {
    const refRootContainer: Ref<HTMLElement> = ref();
    const refRowNodeRoot: Ref<HTMLElement> = ref();
    const isRowIntersecting = ref(false);
    provide('isRowIntersecting', isRowIntersecting);

    const { destroyObserver } = useIntersectionObserver(
      () => refRootContainer.value,
      entry => {
        if (entry.isIntersecting) {
          isRowIntersecting.value = true;
          nextTick(destroyObserver);
        }
      },
    );

    const handleRowClick = (e: MouseEvent) => {
      emit('row-click', e);
    };

    const handleRowMousedown = (e: MouseEvent) => {
      emit('row-mousedown', e);
    };

    const handleRowMouseup = (e: MouseEvent) => {
      emit('row-mouseup', e);
    };

    const handleRowMouseenter = (e: MouseEvent) => {
      emit('row-mouseenter', e);
    };

    const handleRowMouseleave = (e: MouseEvent) => {
      emit('row-mouseleave', e);
    };

    const renderRowVNode = () => {
      return (
        <div
          ref={refRootContainer}
          data-row-index={props.rowIndex}
          onClick={handleRowClick}
          onMousedown={handleRowMousedown}
          onMouseenter={handleRowMouseenter}
          onMouseleave={handleRowMouseleave}
          onMouseup={handleRowMouseup}
        >
          <div
            ref={refRowNodeRoot}
            class={['bklog-row-observe', { 'is-pending': false }]}
            data-row-index={props.rowIndex}
          >
            {slots.default?.()}
          </div>
        </div>
      );
    };
    return {
      renderRowVNode,
    };
  },
  render() {
    return this.renderRowVNode();
  },
});
