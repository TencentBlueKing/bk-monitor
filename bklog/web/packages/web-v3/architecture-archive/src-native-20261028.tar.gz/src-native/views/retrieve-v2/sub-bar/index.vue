<script setup>
  import { computed, ref } from 'vue';

  import useStore from '@/hooks/use-store';
  import { ConditionOperator } from '@/store/condition-operator';
  import { RetrieveUrlResolver } from '@/store/url-resolver';
  import { bkMessage } from 'bk-magic-vue';
  import { isEqual } from 'lodash-es';
  import { useRoute, useRouter } from "vue-router";

  import IndexSetChoice from '../components/index-set-choice/index';
  import { getInputQueryIpSelectItem } from '../search-bar/utils/const.common';
  // #if MONITOR_APP !== 'trace'
  import QueryHistory from './query-history';
  // #else
  // #code const QueryHistory = () => null;
  // #endif
  // #if MONITOR_APP !== 'apm' && MONITOR_APP !== 'trace'
  import FieldSetting from '@/global/field-setting.vue';
  import VersionSwitch from '@/global/version-switch.vue';
  import ClusterSetting from '../setting-modal/index.vue';
  import BarGlobalSetting from './bar-global-setting.tsx';
  import MoreSetting from './more-setting.vue';
  import TimeSetting from './time-setting';
  import WarningSetting from './warning-setting.vue';
  import AutoRefresh from './auto-refresh-new.tsx';
  // #else
  // #code const TimeSetting = () => null;
  // #code const FieldSetting = () => null;
  // #code const VersionSwitch = () => null;
  // #code const ClusterSetting = () => null;
  // #code const BarGlobalSetting = () => null;
  // #code const MoreSetting = () => null;
  // #code const WarningSetting = () => null;
  // #code const AutoRefresh = () => null;
  // #endif

  import * as authorityMap from '@/common/authority-map';
  import { BK_LOG_STORAGE } from '@/store/store.type';
  import { parseTableIdConditions, isFeatureToggleOn } from '@/store/helper';

  import RetrieveHelper, { RetrieveEvent } from '../../retrieve-helper';
  import ShareLink from './share-link.tsx';
  import RetrieveTypeSwitch, { RetrieveType } from './retrieve-type-switch.tsx';
  import { shouldCollapseUnionToSingle, buildSingleIndexPayloadFromUnion } from './union-to-single';

  const props = defineProps({
    showFavorites: {
      type: Boolean,
      default: true,
    },
  });
  const route = useRoute();
  const router = useRouter();
  const store = useStore();

  const isSceneMode = computed(() => store.getters.isSceneMode);
  const isExternal = computed(() => store.state.isExternal);
  const isSceneRetrieveEnabled = computed(
    () =>
      !isExternal.value &&
      isFeatureToggleOn('scene_search', [String(store.state.bkBizId), String(store.state.spaceUid)]),
  );
  const retrieveType = computed(() => (isSceneMode.value ? RetrieveType.Scene : RetrieveType.Normal));
  const fieldSettingRef = ref(null);
  const timeSettingRef = ref(null);
  const isShowClusterSetting = ref(false);
  const indexSetParams = computed(() => store.state.indexItem);

  // 树形索引集列表（选择面板渲染用，避免子节点被摊平到根级导致重复）
  const indexSetList = computed(() => store.state.retrieve.indexSetList);
  // 扁平索引集列表（按 unique_id / index_set_id 查找用）
  const flatIndexSetList = computed(() => store.state.retrieve.flatIndexSetList);

  // 索引集选择结果
  const indexSetValue = computed(() => store.state.indexItem.ids);

  /**
   * 索引ID所属父ID
   */
  const indexSetPid = computed(() => store.state.indexItem.pid ?? []);

  /**
   * 根据当前索引ID和pid生成唯一ID
   */
  const indexSetUid = computed(() => {
    return indexSetValue.value.map((v, index) => `${indexSetPid.value[index] ?? '#'}_${v}`);
  });

  // 索引集类型
  const indexSetType = computed(() => (store.state.indexItem.isUnionIndex ? 'union' : 'single'));

  // 索引集当前激活Tab
  const indexSetTab = computed(() => {
    return store.state.storage[BK_LOG_STORAGE.INDEX_SET_ACTIVE_TAB] ?? indexSetType.value;
  });

  const spaceUid = computed(() => store.state.spaceUid);

  const textDir = computed(() => {
    const textEllipsisDir = store.state.storage[BK_LOG_STORAGE.TEXT_ELLIPSIS_DIR];
    return textEllipsisDir === 'start' ? 'rtl' : 'ltr';
  });

  /** 是否是监控组件 */
  const isMonitorComponent = window.__IS_MONITOR_COMPONENT__;
  const isMonitorTraceComponent = window.__IS_MONITOR_TRACE__;

  // 如果不是采集下发和自定义上报则不展示
  const hasCollectorConfigId = computed(() => {
    const indexSetId = route.params?.indexId;
    const currentIndexSet = flatIndexSetList.value.find(item => String(item.index_set_id) === String(indexSetId));
    return currentIndexSet?.collector_config_id;
  });

  const isFieldSettingShow = computed(() => {
    return !store.getters.isUnionSearch && !isExternal.value;
  });

  const setRouteParams = (ids, isUnionIndex, pid) => {
    const queryTab = RetrieveHelper.routeQueryTabValueFix(indexSetParams.value.items[0], route.query.tab, isUnionIndex);
    const { search_mode, keyword, addition } = indexSetParams.value;

    router.replace({
      // #if MONITOR_APP !== 'apm' && MONITOR_APP !== 'trace'
      params: {
        ...route.params,
        indexId: isUnionIndex ? undefined : ids[0],
      },
      // #endif
      query: {
        ...route.query,
        ...queryTab,
        // #if MONITOR_APP === 'apm' || MONITOR_APP === 'trace'
        indexId: isUnionIndex ? undefined : ids[0],
        // #endif
        search_mode,
        keyword,
        addition: JSON.stringify(addition),
        unionList: isUnionIndex ? JSON.stringify(ids) : undefined,
        clusterParams: undefined,
        pid: JSON.stringify(pid),
        [BK_LOG_STORAGE.HISTORY_ID]: store.state.storage[BK_LOG_STORAGE.HISTORY_ID],
        [BK_LOG_STORAGE.FAVORITE_ID]: store.state.storage[BK_LOG_STORAGE.FAVORITE_ID],
      },
    });
  };

  const setRouteQuery = () => {
    const query = { ...route.query };
    const { keyword, addition, ip_chooser, search_mode, begin, size } = store.getters.retrieveParams;

    const resolver = new RetrieveUrlResolver({
      keyword,
      addition,
      ip_chooser,
      search_mode,
      begin,
      size,
      [BK_LOG_STORAGE.HISTORY_ID]: store.state.storage[BK_LOG_STORAGE.HISTORY_ID],
      [BK_LOG_STORAGE.FAVORITE_ID]: store.state.storage[BK_LOG_STORAGE.FAVORITE_ID],
    });

    Object.assign(query, resolver.resolveParamsToUrl());

    router.replace({
      query,
    });
  };

  const handleIndexSetSelected = async payload => {
    if (!isEqual(indexSetParams.value.ids, payload.ids) || indexSetParams.value.isUnionIndex !== payload.isUnionIndex) {
      /** 索引集默认条件 */
      let indexSetDefaultCondition = {};
      /** 只选择一个索引集且ui模式和sql模式都没有值, 取索引集默认条件
       *  如果是监控组件，切换采集项的时候也取对应索引集默认条件
       */
      if (
        payload.items.length === 1 &&
        ((!indexSetParams.value.addition.length && !indexSetParams.value.keyword) || isMonitorComponent)
      ) {
        if (payload.items[0]?.query_string) {
          indexSetDefaultCondition = {
            keyword: payload.items[0].query_string,
            search_mode: 'sql',
            addition: [],
          };
        } else if (payload.items[0]?.addition) {
          indexSetDefaultCondition = {
            addition: [...payload.items[0].addition],
            search_mode: 'ui',
            keyword: '',
          };
        } else if (!payload.items[0]?.addition && isMonitorComponent) {
          // 监控下当切换采集项没有addtion时，要置空addition
          indexSetDefaultCondition = {
            addition: [],
            search_mode: 'ui',
            keyword: '',
          };
        }
        if (indexSetDefaultCondition.search_mode) {
          store.commit('updateStorage', {
            [BK_LOG_STORAGE.SEARCH_TYPE]: ['ui', 'sql'].indexOf(indexSetDefaultCondition.search_mode),
          });
        }
      }

      RetrieveHelper.setIndexsetId(payload.ids, payload.isUnionIndex ? 'union' : 'single', false);
      RetrieveHelper.fire(RetrieveEvent.TREND_GRAPH_PENDING);
      store.commit('updateUnionIndexList', payload.isUnionIndex ? (payload.ids ?? []) : []);
      store.commit('updateIndexItem', { ...payload, ...indexSetDefaultCondition });

      if (!payload.isUnionIndex) {
        store.commit('updateState', { indexId: payload.ids[0] });
      }

      store.commit('updateSqlQueryFieldList', []);
      store.commit('updateIndexSetQueryResult', {
        row_keys: [],
        row_query_key: '',
        cached_count: 0,
        exception_msg: '',
        is_error: false,
      });

      store.dispatch('requestIndexSetFieldInfo').then(resp => {
        RetrieveHelper.fire(RetrieveEvent.TREND_GRAPH_SEARCH);

        if (resp?.data?.fields?.length) {
          store.dispatch('requestIndexSetQuery');
        }

        if (!resp?.data?.fields?.length) {
          store.commit('updateIndexSetQueryResult', {
            is_error: true,
            exception_msg: 'index-set-field-not-found',
          });
        }
      });

      setRouteParams(payload.ids, payload.isUnionIndex, payload.pid);
    } else {
      if (payload.pid?.length && !isEqual(payload.pid, indexSetPid.value)) {
        store.commit('updateIndexItem', { pid: payload.pid });
        router.replace({
          // #if MONITOR_APP !== 'apm' && MONITOR_APP !== 'trace'
          params: {
            ...route.params,
          },
          // #endif
          query: {
            ...route.query,
            pid: JSON.stringify(payload.pid),
          },
        });
      }
    }
  };

  const handleHistoryChange = payload => {
    const {
      keyword,
      addition,
      ip_chooser,
      search_mode: searchMode,
      scene_filter_values: sceneFilterValues,
      table_id_conditions: tableIdConditions,
    } = payload;
    const foramtAddition = (addition ?? []).map(item => {
      const instance = new ConditionOperator(item);
      return instance.formatApiOperatorToFront();
    });

    if (Object.keys(ip_chooser).length) {
      foramtAddition.unshift(getInputQueryIpSelectItem(ip_chooser));
    }

    const mode = ['ui', 'sql'].includes(searchMode) ? searchMode : 'ui';

    store.commit('updateIndexItemParams', {
      keyword,
      addition: foramtAddition,
      ip_chooser,
      begin: 0,
      search_mode: mode,
    });

    store.commit('updateStorage', { [BK_LOG_STORAGE.SEARCH_TYPE]: ['ui', 'sql'].indexOf(mode) });

    setRouteQuery();
    // 场景化检索模式：解析 table_id_conditions 和 scene_filter_values，先请求字段列表再检索
    if (store.getters.isSceneMode && (tableIdConditions || sceneFilterValues)) {
      const { scene_active, scene_filter_values: parsedFilterValues } = parseTableIdConditions(
        tableIdConditions,
        sceneFilterValues,
      );
      store.commit('updateIndexItemParams', {
        scene_active,
        scene_filter_values: parsedFilterValues,
      });
      setTimeout(() => {
        store.dispatch('requestIndexSetFieldInfo').then(resp => {
          if (resp?.data?.fields?.length) {
            store.dispatch('requestIndexSetQuery');
            RetrieveHelper.fire(RetrieveEvent.TREND_GRAPH_SEARCH);
          } else {
            RetrieveHelper.fire(RetrieveEvent.SCENE_FIELD_EMPTY);
          }
        });
      });
      return;
    }

    setTimeout(() => {
      store.dispatch('requestIndexSetQuery');
      RetrieveHelper.fire(RetrieveEvent.TREND_GRAPH_SEARCH);
    });
  };

  const handleActiveTypeChange = type => {
    const storage = { [BK_LOG_STORAGE.INDEX_SET_ACTIVE_TAB]: type };
    if (['union', 'single'].includes(type)) {
      Object.assign(storage, { [BK_LOG_STORAGE.FAVORITE_ID]: undefined, [BK_LOG_STORAGE.HISTORY_ID]: undefined });
    }

    // 多选切单选：立即收敛为原多选项第 0 项，并走完整选中同步（清 unionList / 写 indexId）
    // 必须在改 isUnionIndex 之前调用，否则 ids 不变时 handleIndexSetSelected 会跳过，残留多选参数
    if (shouldCollapseUnionToSingle(type, indexSetType.value)) {
      const firstUid = indexSetUid.value[0];
      const payload = buildSingleIndexPayloadFromUnion(firstUid, flatIndexSetList.value);
      if (payload) {
        Object.assign(storage, {
          [BK_LOG_STORAGE.LAST_INDEX_SET_ID]: {
            ...(store.state.storage[BK_LOG_STORAGE.LAST_INDEX_SET_ID] ?? {}),
            [spaceUid.value]: [firstUid],
          },
        });
        store.commit('updateStorage', storage);
        handleIndexSetSelected(payload);
        return;
      }
    }

    if (['union', 'single'].includes(type)) {
      store.commit('updateIndexItem', {
        isUnionIndex: type === 'union',
      });
    }

    store.commit('updateStorage', storage);
  };

  const handleIndexSetValueChange = (values, type, id) => {
    const storage = {
      [BK_LOG_STORAGE.LAST_INDEX_SET_ID]: {
        ...(store.state.storage[BK_LOG_STORAGE.LAST_INDEX_SET_ID] ?? {}),
        [spaceUid.value]: values,
      },
    };
    if (['single', 'union'].includes(type)) {
      store.commit('updateIndexItem', {
        isUnionIndex: type === 'union',
      });

      if (type === 'union') {
        store.commit('updateUnionIndexList', { updateIndexItem: false, list: store.state.indexItem.ids });
      }

      Object.assign(storage, {
        [BK_LOG_STORAGE.FAVORITE_ID]: undefined,
        [BK_LOG_STORAGE.HISTORY_ID]: undefined,
      });
    }

    if ('favorite' === indexSetTab.value) {
      Object.assign(storage, { [BK_LOG_STORAGE.FAVORITE_ID]: id, [BK_LOG_STORAGE.HISTORY_ID]: undefined });
    }

    if ('history' === indexSetTab.value) {
      Object.assign(storage, { [BK_LOG_STORAGE.FAVORITE_ID]: undefined, [BK_LOG_STORAGE.HISTORY_ID]: id });
    }

    store.commit('updateStorage', storage);
    const items = flatIndexSetList.value.filter(item => (values ?? []).includes(item.unique_id));
    const idxIdList = [];
    const idexPidList = [];
    values.forEach(v => {
      const [pid, id] = v.split('_');
      idxIdList.push(id);
      idexPidList.push(pid);
    });
    handleIndexSetSelected({ ids: idxIdList, isUnionIndex: indexSetType.value === 'union', items, pid: idexPidList });
  };

  const handleAuthRequest = item => {
    try {
      store
        .dispatch('getApplyData', {
          action_ids: [authorityMap.SEARCH_LOG_AUTH],
          resources: [
            {
              type: 'indices',
              id: item.index_set_id,
            },
          ],
        })
        .then(res => {
          window.open(res.data.apply_url);
        });
    } catch (err) {
      console.warn(err);
    }
  };

  /**
   * @description: 打开 索引集配置 抽屉页
   */
  function handleIndexConfigSliderOpen() {
    if (isFieldSettingShow.value) {
      RetrieveHelper.setAliasConfigOpen(true);
    } else {
      bkMessage({
        theme: 'primary',
        message: '第三方ES、计算平台索引集类型不支持自定义分词',
      });
    }
  }
</script>
<template>
  <div class="subbar-container">
    <RetrieveTypeSwitch
      v-if="isSceneRetrieveEnabled"
      :style="{ margin: `0 ${retrieveType === RetrieveType.Normal ? 8 : 0}px 0 8px` }"
    />
    <div
      :style="{ 'margin-left': props.showFavorites ? '4px' : '0' }"
      class="box-biz-select"
    >
      <IndexSetChoice
        v-if="retrieveType === RetrieveType.Normal"
        width="100%"
        :active-tab="indexSetTab"
        :active-type="indexSetType"
        :index-set-list="indexSetList"
        :index-set-value="indexSetUid"
        :space-uid="spaceUid"
        :text-dir="textDir"
        @auth-request="handleAuthRequest"
        @type-change="handleActiveTypeChange"
        @value-change="handleIndexSetValueChange"
      />

      <QueryHistory
        v-if="!isMonitorTraceComponent"
        @change="handleHistoryChange"
      />
    </div>
    <div
      v-if="!isMonitorComponent"
      class="box-right-option"
    >
      <TimeSetting ref="timeSettingRef" />
      <span class="custom-border" />
      <AutoRefresh class="custom-border-right" />
      <ShareLink v-if="!isExternal" />
      <FieldSetting
        v-if="isFieldSettingShow && store.state.spaceUid && hasCollectorConfigId && !isSceneMode"
        ref="fieldSettingRef"
        class="custom-border-right"
      />
      <WarningSetting
        v-if="!isExternal && !isSceneMode"
        class="custom-border-right"
      />
      <ClusterSetting
        v-model="isShowClusterSetting"
        class="custom-border-right"
      />
      <BarGlobalSetting
        v-if="!isSceneMode"
        class="custom-border-right"
        @show-index-config-slider="handleIndexConfigSliderOpen"
      />
      <div
        v-if="!isExternal && !isSceneMode"
        class="more-setting"
      >
        <MoreSetting :is-show-cluster-setting.sync="isShowClusterSetting" />
      </div>
      <VersionSwitch
        v-if="!isSceneMode"
        style="border-left: 1px solid #eaebf0"
        version="v2"
      />
    </div>
  </div>
</template>
<style lang="scss">
  @import './index.scss';

  .box-right-option {
    .more-setting {
      height: 100%;

      &:hover {
        background: #f5f7fa;
      }
    }

    .custom-border-right {
      display: flex;
      align-items: center;
      height: 100%;
      line-height: 20px;
      border-right: 1px solid #eaebf0;

      &:hover {
        background: #f5f7fa;
      }

      &.query-params-wrap {
        .__bk_date_picker__ {
          color: #4d4f56;

          .date-icon {
            color: #4d4f56;
          }

          .date-content {
            padding: 0;

            & > svg {
              fill: #4d4f56;
            }
          }
        }
      }
    }
  }
</style>
