<script setup>
  import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue';

  import useLocale from '@/hooks/use-locale';
  import useStore from '@/hooks/use-store';
  import { BK_LOG_STORAGE } from '@/store/store.type';
  import RetrieveHelper, { RetrieveEvent } from '@/views/retrieve-helper';

  import FieldFilterComp from '../field-filter-comp';
  const store = useStore();
  const { $t } = useLocale();
  const props = defineProps({
    value: { type: Boolean, default: true },
    width: { type: Number, default: 200 },
  });
  const emit = defineEmits(['input', 'field-status-change']);

  const showFieldAlias = computed(() => store.state.storage[BK_LOG_STORAGE.SHOW_FIELD_ALIAS]);
  /** 时间选择器绑定的值 */
  const datePickerValue = computed(() => {
    const { start_time: startTime = 'now-15m', end_time: endTime = 'now' } = store.state.indexItem;
    return [startTime, endTime];
  });

  const indexSetItem = computed(() => {
    return store.state.indexItem;
  });

  const sortList = computed(() => {
    return store.state.indexFieldInfo.sort_list;
  });

  const sourceFields = computed(() => store.getters.filteredFieldList ?? []);
  // 千级字段进 store 后先让 search XHR 出去，下一帧再把列表交给左侧面板，避免首屏 flush 挡住检索。
  const deferredFields = ref([]);
  let fieldPaintFrame = 0;
  watch(
    sourceFields,
    fields => {
      if (fieldPaintFrame) {
        cancelAnimationFrame(fieldPaintFrame);
      }
      fieldPaintFrame = requestAnimationFrame(() => {
        fieldPaintFrame = 0;
        deferredFields.value = fields;
      });
    },
    { immediate: true },
  );
  onBeforeUnmount(() => {
    if (fieldPaintFrame) {
      cancelAnimationFrame(fieldPaintFrame);
    }
  });

  const totalFields = computed(() => deferredFields.value);

  const fieldAliasMap = computed(() => {
    const fieldAliasMap = {};
    totalFields.value.forEach(item => {
      if (item?.is_virtual_alias_field) {
        return;
      }
      fieldAliasMap[item.field_name] = item.query_alias || item.field_name;
    });

    return fieldAliasMap;
  });

  const requestAddition = computed(() => store.getters.requestAddition);

  const retrieveParams = computed(() => {
    return {
      bk_biz_id: store.state.bkBizId,
      ...store.getters.retrieveParams,
      start_time: datePickerValue.value[0],
      end_time: datePickerValue.value[1],
      addition: requestAddition.value ?? [],
      showFieldAlias: store.state.storage[BK_LOG_STORAGE.SHOW_FIELD_ALIAS],
    };
  });

  const visibleFields = computed(() => store.getters.visibleFields ?? []);
  const rootStyle = computed(() => ({
    '--root-width': `${props.width}px`,
  }));

  /**
   * @desc: 字段设置更新了
   * @param {Array} displayFieldNames 展示字段
   */
  const handleFieldsUpdated = async displayFieldNames => {
    store.dispatch('userFieldConfigChange', {
      displayFields: displayFieldNames,
    });
    await nextTick();
    store.commit('resetVisibleFields', { displayFieldNames, version: 'v2' });
    store.commit('updateIsSetDefaultTableColumn', false);
    RetrieveHelper.fire(RetrieveEvent.VISIBLE_FIELD_COLUMN_LAYOUT_CHANGE);
  };
  const handleCloseFilterTitle = isTextClick => {
    if (isTextClick && props.value) return;
    emit('field-status-change', !props.value);
    emit('input', !props.value);
  };
</script>

<template>
  <div
    :class="['search-field-filter-new', { 'is-close': !value }]"
    :style="rootStyle"
  >
    <!-- 字段过滤 -->
    <div class="tab-item-title field-filter-title">
      <div
        class="close-total"
        @click="handleCloseFilterTitle(false)"
      >
        <span
          v-bk-tooltips="{ content: value ? $t('收起') : $t('打开') }"
          :style="{ transform: value ? '' : 'rotate(180deg)' }"
          style="font-size: 14px"
          class="bklog-icon bklog-collapse"
        ></span>
      </div>
    </div>
    <FieldFilterComp
      v-show="value"
      ref="fieldFilterRef"
      :date-picker-value="datePickerValue"
      :field-alias-map="fieldAliasMap"
      :index-set-item="indexSetItem"
      :retrieve-params="retrieveParams"
      :show-field-alias="showFieldAlias"
      :sort-list="sortList"
      :total-fields="totalFields"
      :visible-fields="visibleFields"
      @fields-updated="handleFieldsUpdated"
    />
  </div>
</template>

<style lang="scss">
  @import './field-filter.scss';
</style>
