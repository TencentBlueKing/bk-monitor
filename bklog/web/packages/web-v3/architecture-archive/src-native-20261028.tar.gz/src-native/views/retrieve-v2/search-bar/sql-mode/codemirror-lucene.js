/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */
import { sql } from '@codemirror/lang-sql';
import { EditorState, EditorSelection } from '@codemirror/state';
import { keymap, EditorView, Decoration } from '@codemirror/view';
import { minimalSetup } from 'codemirror';
import { debounce } from 'lodash-es';

const notKeywordDecorator = Decoration.mark({
  class: 'cm-not-keyword', // 这将添加一个cm-not-keyword类名
});

function highlightNotKeywords() {
  return EditorView.decorations.of(view => {
    const decorations = [];
    const text = view.state.doc.toString();
    const regex = /\bNOT\b/g;

    let match;
    while ((match = regex.exec(text)) !== null) {
      decorations.push(notKeywordDecorator.range(match.index, match.index + match[0].length));
    }

    return Decoration.set(decorations);
  });
}

/**
 * 创建Lucene编辑器
 * @param {Object} params 参数
 * @param {HTMLElement} params.target 目标元素
 * @param {Function} params.onChange 变化回调
 * @param {Function} params.onFocusChange 焦点变化回调
 * @param {Function} params.onFocusPosChange 焦点位置变化回调
 * @param {Function} params.onKeyEnter 回车回调
 * @param {String} params.value 初始值
 * @param {Function} params.stopDefaultKeyboard 阻止默认键盘行为回调 'ArrowUp', 'ArrowDown'
 */
export default ({
  target,
  onChange,
  onFocusChange,
  onFocusPosChange,
  onKeyEnter,
  onCtrlEnter,
  value,
  stopDefaultKeyboard,
}) => {
  // 键盘操作事件处理函数
  // 这里通过回调函数处理，如果 stopDefaultKeyboard 返回true，则会阻止编辑器默认的监盘行为
  const stopKeyboardList = ['ArrowUp', 'ArrowDown'].map(keymap => ({
    key: keymap,
    run: () => {
      return stopDefaultKeyboard?.() ?? false;
    },
  }));

  const debouncedTrack = debounce(update => {
    onChange?.(update.state.doc);
    onFocusPosChange?.(update.state);
  });

  const state = EditorState.create({
    doc: value,
    extensions: [
      keymap.of([
        {
          key: 'Enter',
          mac: 'Enter',
          run: view => {
            // 检查是否正在输入法组合过程中
            if (isComposing || view.dom.getAttribute('data-composing') === 'true') {
              return false;
            }
            return onKeyEnter?.(view) ?? false;
          },
        },
        {
          key: 'Ctrl-Enter',
          mac: 'Cmd-Enter',
          run: view => {
            // Ctrl+Enter 通常不受输入法影响，但为了安全也检查一下
            if (isComposing || view.dom.getAttribute('data-composing') === 'true') {
              return false;
            }
            return onCtrlEnter?.(view) ?? false;
          },
        },
        ...stopKeyboardList,
      ]),
      minimalSetup,
      sql(),
      highlightNotKeywords(),
      EditorView.lineWrapping,

      EditorView.focusChangeEffect.of((state, focusing) => {
        onFocusChange?.(state, focusing);
      }),
      EditorView.updateListener.of(update => {
        if (update.selectionSet) {
          onFocusPosChange?.(update.state);
        }
        if (update.docChanged) {
          debouncedTrack(update);
        }
      }),
    ],
  });

  const view = new EditorView({
    state,
    parent: target,
  });

  // 添加输入法组合事件监听
  let isComposing = false;
  const handleCompositionStart = () => {
    isComposing = true;
    view.dom.setAttribute('data-composing', 'true');
  };
  const handleCompositionEnd = () => {
    isComposing = false;
    view.dom.removeAttribute('data-composing');
  };

  // 在编辑器的 DOM 上添加 composition 事件监听
  view.dom.addEventListener('compositionstart', handleCompositionStart);
  view.dom.addEventListener('compositionend', handleCompositionEnd);

  const appendText = value => {
    view.dispatch({
      changes: { from: view.state.doc.length, insert: value },
    });
  };

  const setValue = (value, from = 0, to = undefined) => {
    const currentValue = view.state.doc.toString();
    if (currentValue === value) {
      return;
    }

    // 处理替换全部内容的情况
    if (to === Infinity) {
      const docLength = view.state.doc.length;
      view.dispatch({
        changes: { from: 0, to: docLength, insert: value },
        selection: EditorSelection.cursor(value.length),
      });
      return;
    }

    // 处理插入新内容的情况
    if (to === undefined) {
      // 确保 from 不超过文档长度
      const safeFrom = Math.min(from, view.state.doc.length);
      view.dispatch({
        changes: { from: safeFrom, insert: value },
        selection: EditorSelection.cursor(safeFrom + value.length),
        userEvent: 'input',
      });
      return;
    }

    // 处理替换指定范围内容的情况
    if (typeof to === 'number') {
      // 确保 from 和 to 在有效范围内
      const docLength = view.state.doc.length;
      const safeFrom = Math.min(from, docLength);
      const safeTo = Math.min(to, docLength);

      // 如果 from 大于等于 to，当作插入处理
      if (safeFrom >= safeTo) {
        view.dispatch({
          changes: { from: safeFrom, insert: value },
          selection: EditorSelection.cursor(safeFrom + value.length),
          userEvent: 'input',
        });
        return;
      }

      view.dispatch({
        changes: { from: safeFrom, to: safeTo, insert: value },
        selection: EditorSelection.cursor(safeFrom + value.length),
        userEvent: 'input',
      });
    }
  };

  const setFocus = focusPosition => {
    if (!view) return;

    view.focus();
    // 确保光标位置在有效范围内
    const docLength = view.state.doc.length;
    const pos = typeof focusPosition === 'number' ? Math.min(Math.max(0, focusPosition), docLength) : 0;

    view.dispatch({
      selection: EditorSelection.cursor(pos),
      userEvent: 'focus',
    });
  };

  const getValue = () => {
    return view.state.doc.toString() ?? '*';
  };

  const destroy = () => {
    // 清理 composition 事件监听器
    view.dom.removeEventListener('compositionstart', handleCompositionStart);
    view.dom.removeEventListener('compositionend', handleCompositionEnd);
    // 销毁编辑器视图
    view.destroy();
  };

  return {
    state,
    view,
    appendText,
    setValue,
    setFocus,
    getValue,
    destroy,
  };
};
