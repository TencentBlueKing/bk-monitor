/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

export interface SceneEmptyViewInput {
  isSceneMode: boolean;
  isSceneFilterEmpty: boolean;
  isFieldListFetched: boolean;
  isFieldListEmpty: boolean;
  isSceneLoading: boolean;
}

export interface SceneEmptyView {
  showSceneEmptyTip: boolean;
  showFieldEmptyTip: boolean;
  hideSearchResult: boolean;
  sceneEmptyTipLoading: boolean;
}

export interface EmptySceneRouteActionInput {
  hasRouteIndexId: boolean;
  isSpaceChanging: boolean;
}

/** 场景化检索结果区空态：未过滤不转圈，已过滤才进入字段 loading / 未匹配 */
export const resolveSceneEmptyView = (input: SceneEmptyViewInput): SceneEmptyView => {
  const { isSceneMode, isSceneFilterEmpty, isFieldListFetched, isFieldListEmpty, isSceneLoading } = input;

  return {
    showSceneEmptyTip: isSceneMode && (isSceneFilterEmpty || !isFieldListFetched),
    showFieldEmptyTip: isSceneMode && !isSceneFilterEmpty && isFieldListEmpty,
    hideSearchResult: isSceneMode && (isSceneFilterEmpty || !isFieldListFetched || isFieldListEmpty),
    sceneEmptyTipLoading: isSceneLoading && !isSceneFilterEmpty,
  };
};

/** 首屏空筛选保留分享 URL；只有切业务时才摘掉旧业务 indexId。 */
export const shouldStripIndexIdOnEmptyScene = (input: EmptySceneRouteActionInput): boolean =>
  input.isSpaceChanging && input.hasRouteIndexId;
