/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import Vue from 'vue';
import LogIcon from '@/components/log-icon';

import i18n from '@/language/i18n';
import JsonFormatWrapper from '@/global/json-format-wrapper.vue';
import useStore from '@/hooks/use-store';
import { performanceMonitorService } from '@/storage';

import MonitorApmLog from './monitor';
if (!window.mainComponent?.$t) {
  window.mainComponent = {
    $t: i18n.t.bind(i18n),
    $i18n: i18n,
  };
}

const logStore = useStore();

const initMonitorState = payload => {
  logStore.commit('initMonitorState', payload);
};
const initGlobalComponents = () => {
  Vue.component('JsonFormatWrapper', JsonFormatWrapper);
  Vue.component('LogIcon', LogIcon);
};
const initWindowState = () => {
  window.__IS_MONITOR_COMPONENT__ = true;
  window.__IS_MONITOR_TRACE__ = false;
  window.__IS_MONITOR_APM__ = true;
  // 为嵌入运行时注册 workerManager / __BKLOG_WORKERS__ 诊断 API。
  performanceMonitorService.init();
};
export { MonitorApmLog, logStore, i18n, initMonitorState, initGlobalComponents, initWindowState };
