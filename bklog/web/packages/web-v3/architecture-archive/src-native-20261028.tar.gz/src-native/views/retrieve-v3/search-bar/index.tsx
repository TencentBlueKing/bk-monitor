/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import { computed, defineComponent, ref, nextTick, watch, onBeforeUnmount } from 'vue';

import useElementEvent from '@/hooks/use-element-event';
import useLocale from '@/hooks/use-locale';
import useResizeObserve from '@/hooks/use-resize-observe';
import useStore from '@/hooks/use-store';
import useRetrieveParams from '@/hooks/use-retrieve-params';
import aiBluekingSvg from '@/images/ai/ai-bluking-2.svg';
import RetrieveHelper, { RetrieveEvent } from '../../retrieve-helper';
import V2SearchBar from '../../retrieve-v2/search-bar/index.vue';
import V3AiMode from './ai-mode/index';
import { bkMessage } from 'bk-magic-vue';

import { handleTransformToTimestamp } from '@/components/time-range/utils';
import { AiQueryResult, AiQueryContent } from './types';
import { BK_LOG_STORAGE } from '@/store/store.type';

import './index.scss';

const DEFAULT_AI_QUERY_RESULT: AiQueryResult = {
  startTime: '',
  endTime: '',
  queryString: '',
  parseResult: undefined,
  explain: '',
};

export default defineComponent({
  name: 'V3Searchbar',
  setup() {
    const { t } = useLocale();
    const store = useStore();

    const searchBarHeight = ref(0);
    const searchBarRef = ref<any>(null);
    const aiModeRef = ref<any>(null);

    const isAiLoading = ref(false);
    const searchMode = ref<'normal' | 'ai'>('normal');
    const aiQueryResult = ref<AiQueryResult>(DEFAULT_AI_QUERY_RESULT);

    const aiFilterList = computed<string[]>(() =>
      (store.state.aiMode.filterList ?? []).filter(f => !/^\s*\*?\s*$/.test(f)),
    );

    const { setRouteParamsByKeywordAndAddition } = useRetrieveParams();

    const shortcutKeyStyle = {
      width: '20px',
      height: '20px',
      background: '#A3B1CC',
      borderRadius: '10px',
      color: '#ffffff',
      fontSize: '14px',
      textAlign: 'center' as const,
      display: 'inline-flex' as const,
      alignItems: 'center' as const,
      justifyContent: 'center' as const,
    };

    const isMonitorApm = window.__IS_MONITOR_APM__;
    const isMonitorTrace = window.__IS_MONITOR_TRACE__;

    /**
     * 获取字段配置
     */
    const fieldsJsonValue = computed(() => {
      const fieldConfig = {};
      for (const field of store.getters.rawFieldList) {
        fieldConfig[field.field_name] = {
          type: field.field_type,
          ...(field.query_alias ? { query_alias: field.query_alias } : {}),
        };
      }
      return JSON.stringify(fieldConfig);
    });

    /**
     * 是否激活AI助手
     * @TODO 本周发布BKOP开启助手，上云环境关闭助手，此处需要暂时调整为 false
     */
    const isAiAssistantActive = computed(() => store.state.features.isAiAssistantActive);
    const formatValue = computed(() => store.getters.retrieveParams.format);

    /**
     * 当前搜索模式：'ui' | 'sql'
     */
    const currentSearchMode = computed<'ui' | 'sql'>(() =>
      store.state.storage[BK_LOG_STORAGE.SEARCH_TYPE] === 1 ? 'sql' : 'ui',
    );
    /**
     * 更新AI助手位置
     */
    const updateAiAssitantPosition = () => {
      if (RetrieveHelper.aiAssitantHelper.isShown()) {
        const rect = searchBarRef.value?.getRect();
        const left = rect?.left;
        const top = rect?.top + rect?.height + 4;
        const width = rect?.width;
        const height = 480;
        RetrieveHelper.aiAssitantHelper.setPosition(left, top, width, height);
      }
    };

    /**
     * 用于处理搜索栏高度变化
     * @param height 搜索栏高度
     */
    const handleHeightChange = height => {
      if (height === searchBarHeight.value || RetrieveHelper.aiAssitantHelper.activePosition !== 'search-bar') {
        return;
      }

      searchBarHeight.value = height;
      RetrieveHelper.setSearchBarHeight(height);
      updateAiAssitantPosition();
    };

    /**
     * 处理 Tab 键切换模式
     * @param e 键盘事件
     */
    const handleTabKeyPress = (e: KeyboardEvent, isMouseClick = false) => {
      // 如果 AI 助手未启用，则不处理 Tab 事件
      if (!isAiAssistantActive.value) {
        return;
      }

      if (isAiLoading.value) {
        return;
      }
      // 检查是否按下了 Tab 键（排除 Shift+Tab）
      if (isMouseClick || ((e.key === 'Tab' || e.keyCode === 9) && !e.shiftKey && !e.ctrlKey)) {
        // 阻止默认的 Tab 行为
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        // 切换模式
        if (searchMode.value === 'normal') {
          // 从非 AI 模式切换到 AI 模式
          const keyword = store.getters.retrieveParams.keyword;

          // 将 keyword 添加为 filterList 的一个选项（过滤空值和通配符）
          store.state.aiMode.filterList = [keyword].filter(f => !/^\s*\*?\s*$/.test(f));
          store.state.aiMode.active = true;

          store.commit('updateAiMode', {
            active: true,
            filterList: [keyword].filter(f => !/^\s*\*?\s*$/.test(f)),
          });

          store.commit('updateIndexItemParams', { keyword: '' });
          aiQueryResult.value.queryString = '';
          aiQueryResult.value.parseResult = undefined;
          aiQueryResult.value.explain = undefined;

          // 更新路由参数以同步状态
          setRouteParamsByKeywordAndAddition();

          searchMode.value = 'ai';

          // 打点：通过Tab键切换到AI模式
          RetrieveHelper.reportLog(
            {
              ai_scenario: 'tab_switch',
              trigger_source: 'tab_key',
              action: 'tab',
            },
            store.state,
          );

          // 切换到 AI 模式后，聚焦到 AI 输入框
          nextTick(() => {
            const aiModeEl = aiModeRef.value?.$el || aiModeRef.value;
            const aiTextarea = aiModeEl?.querySelector?.('textarea');
            if (aiTextarea) {
              aiTextarea.focus();
            }
          });
        } else {
          // 从 AI 模式切换回非 AI 模式
          // 收集 filterList 和 AI 查询结果，合并为 keyword
          const keywordParts: string[] = [];

          // 添加 filterList 中的所有项
          if (aiFilterList.value.length > 0) {
            keywordParts.push(...aiFilterList.value);
          }

          // 添加 AI 查询结果（如果存在）
          if (aiQueryResult.value.queryString && aiQueryResult.value.queryString.trim()) {
            keywordParts.push(aiQueryResult.value.queryString.trim());
          }

          // 用 ' AND ' 连接所有部分
          const keyword = keywordParts.join(' AND ');

          // 先更新 storage 和 indexItem，确保 V2SearchBar 能读取到正确的模式
          store.commit('updateStorage', { [BK_LOG_STORAGE.SEARCH_TYPE]: 1 });
          store.commit('updateIndexItemParams', { keyword, search_mode: 'sql' });

          // 更新路由参数以同步状态（需要在 nextTick 之前更新，确保路由参数正确）
          setRouteParamsByKeywordAndAddition();

          searchMode.value = 'normal';
          store.state.aiMode.active = false;
          store.state.aiMode.filterList = [];
          Object.assign(aiQueryResult.value, {
            startTime: undefined,
            endTime: undefined,
            queryString: undefined,
            parseResult: undefined,
            explain: undefined,
          });

          // 切换到常规模式后，点击搜索框容器以触发自动 focus
          nextTick(() => {
            const searchBarEl = searchBarRef.value?.$el || searchBarRef.value;
            // 找到搜索框容器，点击后会自动触发 focus
            const searchInputContainer =
              searchBarEl?.querySelector?.('.search-bar-container') || searchBarEl?.querySelector?.('.search-input');
            if (searchInputContainer) {
              searchInputContainer.click();
            }
          });
        }
      }
    };

    /**
     * 监听搜索栏Size变化，更新AI助手位置
     */
    useResizeObserve(() => searchBarRef.value, updateAiAssitantPosition);

    /**
     * 添加事件
     */
    const { addElementEvent } = useElementEvent();
    addElementEvent(document.body, 'click', (e: MouseEvent) => {
      RetrieveHelper.aiAssitantHelper.closeAiAssitantWithSearchBar(e);
    });

    addElementEvent(document, 'keydown', handleTabKeyPress, { capture: true });

    /**
     * 使用AI编辑
     * @param e 鼠标事件
     */
    const handleAiSpanClick = (e: MouseEvent) => {
      // e.stopPropagation();
      // e.preventDefault();
      // e.stopImmediatePropagation();

      // 打点：点击AI编辑按钮打开对话框
      RetrieveHelper.reportLog(
        {
          ai_scenario: 'ai_edit_dialog',
          trigger_source: `${currentSearchMode.value}_mode`,
          action: 'click',
        },
        store.state,
      );

      handleTabKeyPress(e as any, true);
      // const rect = searchBarRef.value?.getRect();
      // const left = rect?.left;
      // const top = rect?.top + rect?.height + 4;
      // const width = rect?.width;

      // RetrieveHelper.aiAssitantHelper.showAiAssitant(
      //   {
      //     defaultLeft: left,
      //     defaultTop: top,
      //     defaultWidth: width,
      //     defaultHeight: 560,
      //     draggable: false,
      //     defaultChatInputPosition: 'bottom',
      //     showCompressionIcon: false,
      //     showNewChatIcon: false,
      //     showMoreIcon: false,
      //     maxWidth: '100%',
      //     title: t('AI编辑'),
      //   },
      //   {
      //     index_set_id: store.state.indexItem.ids[0],
      //     description: '',
      //     domain: window.location.origin,
      //     fields: fieldsJsonValue.value,
      //   },
      // );
    };

    /**
     * 处理请求响应
     * @param resp {FetchResponse<T>}
     */
    const handleRequestResponse = (resp?: any) => {
      const content = resp?.choices[0]?.delta?.content ?? '{}';
      try {
        // 兼容 AI 响应内容被 markdown 代码块包裹的情况（如 ```json\n{...}\n```）
        let jsonStr = content.trim();
        const codeBlockMatch = jsonStr.match(/^```(?:json)?\s*\n?([\s\S]*?)\n?\s*```$/i);
        if (codeBlockMatch) {
          jsonStr = codeBlockMatch[1].trim();
        }
        const contentObj: AiQueryContent = JSON.parse(jsonStr);
        const {
          end_time: endTime,
          start_time: startTime,
          query_string: queryString = '',
          parse_result: parseResult,
          explain = '',
        } = contentObj;

        const queryParams = { search_mode: 'sql' };
        let needReplace = false;
        if (startTime && endTime) {
          const results = handleTransformToTimestamp([startTime, endTime], formatValue.value);
          Object.assign(queryParams, { start_time: results[0], end_time: results[1] });
          store.commit('updateIndexItemParams', { datePickerValue: [startTime, endTime] });
          aiQueryResult.value.startTime = startTime;
          aiQueryResult.value.endTime = endTime;
          needReplace = true;
        }

        if (queryString !== undefined && queryString !== null) {
          Object.assign(queryParams, { keyword: queryString });
          needReplace = true;
          aiQueryResult.value.queryString = queryString;
        }

        if (needReplace && parseResult !== 'FAILED') {
          store.commit('updateIndexItemParams', queryParams);
          store.commit('updateStorage', { [BK_LOG_STORAGE.SEARCH_TYPE]: 1 });

          const { start_time, end_time } = queryParams as any;
          setRouteParamsByKeywordAndAddition({ start_time, end_time }).then(async () => {
            // 场景化检索模式下条件为空时跳过
            if (store.getters.isSceneMode && store.getters.isSceneFilterEmpty) return;
            // 检索条件有变更时先加载字段信息
            if (store.state.indexItem.isSceneFilterChanged) {
              await store.dispatch('requestIndexSetFieldInfo');
            }
            RetrieveHelper.fire(RetrieveEvent.SEARCH_VALUE_CHANGE);
            store.dispatch('requestIndexSetQuery');
          });
        }

        aiQueryResult.value.parseResult = parseResult;
        aiQueryResult.value.explain = explain;
      } catch (e) {
        console.error(e);
        bkMessage({
          theme: 'error',
          message: e.message,
        });
      }
    };

    /**
     * 使用AI编辑
     * @param value 查询语句
     * @param triggerSource 触发来源：'ui_mode' | 'sql_mode' | 'ai_mode'
     * @returns {void}
     */
    const handleTextToQuery = (value: string, triggerSource: 'ui_mode' | 'sql_mode' | 'ai_mode' = 'ai_mode'): void => {
      isAiLoading.value = true;

      Object.assign(aiQueryResult.value, {
        queryString: '',
        parseResult: undefined,
        explain: undefined,
        startTime: undefined,
        endTime: undefined,
      });

      // 打点：AI 自动补全（统计所有来源：UI/SQL/AI 模式）
      RetrieveHelper.reportLog(
        {
          ai_scenario: 'auto_complete',
          trigger_source: triggerSource,
          action: 'request',
        },
        store.state,
      );

      if (value.length === 0) {
        handleRequestResponse(null);
        isAiLoading.value = false;
        return;
      }

      RetrieveHelper.aiAssitantHelper
        .requestTextToQueryString({
          index_set_id: store.state.indexItem.ids[0],
          description: value,
          domain: window.location.origin,
          fields: fieldsJsonValue.value,
          keyword: value,
        })
        .then(handleRequestResponse)
        .finally(() => {
          isAiLoading.value = false;
        });
    };

    const handleEditSql = () => {
      searchMode.value = 'normal';
    };

    /**
     * 处理 filterList 变化
     * @param newFilterList 新的 filterList
     */
    const handleFilterChange = async (newFilterList: string[]) => {
      // 更新 store 中的 filterList
      store.state.aiMode.filterList = newFilterList;
      // 场景化检索模式下条件为空时跳过检索请求
      if (!(store.getters.isSceneMode && store.getters.isSceneFilterEmpty)) {
        // 检索条件有变更时先加载字段信息
        if (store.state.indexItem.isSceneFilterChanged) {
          await store.dispatch('requestIndexSetFieldInfo');
        }
        // 触发查询
        store.dispatch('requestIndexSetQuery');
      }
      // 更新 URL 参数
      setRouteParamsByKeywordAndAddition();
    };

    const handleCloseAiParsedText = () => {
      aiQueryResult.value.queryString = '';
      aiQueryResult.value.parseResult = undefined;
      aiQueryResult.value.explain = undefined;
      aiQueryResult.value.startTime = undefined;
      aiQueryResult.value.endTime = undefined;
    };

    /** 清理 AI 相关状态 */
    const clearAiState = () => {
      store.commit('updateAiMode', {
        active: false,
        filterList: [],
      });
      handleCloseAiParsedText();
      searchMode.value = 'normal';
    };

    // 切换场景时，清理 AI 相关状态
    watch(
      () => store.state.indexItem.scene_active,
      (newVal, oldVal) => {
        if (newVal !== oldVal) {
          clearAiState();
        }
      },
    );

    onBeforeUnmount(() => {
      clearAiState();
    });

    /**
     * 切换到普通模式
     * @param e 鼠标事件
     */
    const handleModeChange = (e: MouseEvent) => {
      handleTabKeyPress(e as any, true);
    };

    /**
     * 渲染搜索栏
     * @returns
     */
    return () => {
      if (searchMode.value === 'ai') {
        return (
          <div class='v3-search-bar-root is-ai-mode fix-search-bar'>
            <V3AiMode
              ref={aiModeRef}
              is-ai-loading={isAiLoading.value}
              ai-query-result={aiQueryResult.value}
              filter-list={aiFilterList.value}
              onHeightChange={handleHeightChange}
              onModeChange={handleModeChange}
              onTextToQuery={(value: string) => {
                handleTextToQuery(value, 'ai_mode');
              }}
              onEditSql={handleEditSql}
              onFilterChange={handleFilterChange}
            />
          </div>
        );
      }

      return (
        <V2SearchBar
          class={[
            'v3-search-bar-root fix-search-bar',
            {
              'is-monitor-apm': isMonitorApm,
              'is-monitor-trace': isMonitorTrace,
            },
          ]}
          ref={searchBarRef}
          onHeightChange={handleHeightChange}
          onCloseAiParsedText={handleCloseAiParsedText}
          onTextToQuery={(value: string) => {
            // 根据当前模式确定触发来源
            const triggerSource = `${currentSearchMode.value}_mode` as 'ui_mode' | 'sql_mode';

            if (triggerSource === 'sql_mode') {
              store.commit('updateIndexItemParams', { keyword: value });
            }

            handleTextToQuery(value, triggerSource);
          }}
          is-ai-loading={isAiLoading.value}
          ai-query-result={aiQueryResult.value}
          v-slots={{
              'search-tool': () => {
                if (isAiAssistantActive.value) {
                  return (
                    <span
                      class='bklog-ai-edit-btn'
                      onClick={handleAiSpanClick}
                    >
                      <img
                        src={aiBluekingSvg}
                        alt='AI 模式'
                        style={{ width: '18px', height: '18px' }}
                      />
                      {t('AI 模式')}
                      <span style={shortcutKeyStyle}>
                        <i class='bklog-icon bklog-key-tab'></i>
                      </span>
                    </span>
                  );
                }
                return null;
              },
            }}
        ></V2SearchBar>
      );
    };
  },
});
