/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import { computed, defineAsyncComponent, type ComputedRef, defineComponent, onBeforeUnmount } from 'vue';

import { debounce } from 'lodash-es';
import { useRoute, useRouter } from 'vue-router';

import SearchResultPanel from '../../retrieve-v2/search-result-panel/index.vue';
import RetrieveHelper, { RetrieveEvent } from '../../retrieve-helper';
import { RouteQueryTab } from '../index.type';
import useStore from '@/hooks/use-store';
import useRetrieveEvent from '@/hooks/use-retrieve-event';

import './index.scss';

// #if MONITOR_APP !== 'apm' && MONITOR_APP !== 'trace'
const GraphAnalysis = defineAsyncComponent(
  () =>
    import(/* webpackChunkName: 'retrieve-graph-analysis' */ '../../retrieve-v2/search-result-panel/graph-analysis'),
);
const SearchResultTab = defineAsyncComponent(
  () => import(/* webpackChunkName: 'retrieve-result-tab' */ '../../retrieve-v2/search-result-tab/index.vue'),
);
// #else
// #code const GraphAnalysis = () => null
// #code const SearchResultTab = () => null;
// #endif
const Grep = defineAsyncComponent(() => import(/* webpackChunkName: 'retrieve-grep' */ '../grep'));
const LogClustering = defineAsyncComponent(
  () => import(/* webpackChunkName: 'retrieve-log-clustering' */ './log-clustering'),
);

export default defineComponent({
  name: 'V3ResultContainer',
  setup() {
    const router = useRouter();
    const route = useRoute();
    const store = useStore();

    const debounceUpdateTabValue = debounce(value => {
      const isClustering = value === 'clustering';
      router.replace({
        params: { ...(route.params ?? {}) },
        query: {
          ...(route.query ?? {}),
          tab: value,
          ...(isClustering ? {} : { clusterParams: undefined }),
        },
      });
    }, 60);
    const activeTab = computed(() => route.query.tab ?? 'origin') as ComputedRef<string>;

    let trendSearchTimer: ReturnType<typeof setTimeout> | null = null;

    const handleTabChange = (tab: string, triggerTrend = false) => {
      debounceUpdateTabValue(tab);

      if (triggerTrend) {
        store.dispatch('requestIndexSetQuery');
        if (trendSearchTimer) {
          clearTimeout(trendSearchTimer);
        }
        trendSearchTimer = setTimeout(() => {
          RetrieveHelper.fire(RetrieveEvent.TREND_GRAPH_SEARCH);
          trendSearchTimer = null;
        }, 300);
      }
    };

    const handleFavoriteChange = item => {
      debounceUpdateTabValue(item.favorite_type === 'chart' ? 'graph_analysis' : 'origin');
    };

    const { addEvent } = useRetrieveEvent();
    addEvent(RetrieveEvent.FAVORITE_ACTIVE_CHANGE, handleFavoriteChange);

    onBeforeUnmount(() => {
      debounceUpdateTabValue.cancel();
      if (trendSearchTimer) {
        clearTimeout(trendSearchTimer);
        trendSearchTimer = null;
      }
    });

    const renderTabContent = () => {
      if (activeTab.value === RouteQueryTab.GRAPH_ANALYSIS || activeTab.value === RouteQueryTab.GRAPH_ANALYSIS_LEGACY) {
        return <GraphAnalysis></GraphAnalysis>;
      }

      if (activeTab.value === RouteQueryTab.GREP) {
        return <Grep></Grep>;
      }

      if (activeTab.value === RouteQueryTab.CLUSTERING) {
        return <LogClustering />;
      }

      return (
        <SearchResultPanel
          active-tab={activeTab.value}
          onUpdate:active-tab={handleTabChange}
        ></SearchResultPanel>
      );
    };

    return () => (
      <div class='v3-bklog-body'>
        <SearchResultTab
          value={activeTab.value}
          onInput={handleTabChange}
        ></SearchResultTab>
        {renderTabContent()}
      </div>
    );
  },
});
