<!--
* Tencent is pleased to support the open source community by making
* 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
*
* Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
*
* 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
*
* License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
*
* ---------------------------------------------------
* Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
* documentation files (the "Software"), to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
* to permit persons to whom the Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of
* the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
* THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
* CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
* IN THE SOFTWARE.
-->

<template>
  <div
    v-if="listData.length || (mark && title)"
    class="list-box-container"
  >
    <div :class="['list-title', mark && 'mark']">
      <span :class="icon"></span>
      <h2 class="text">{{ title }}</h2>
    </div>
    <ul class="list-box">
      <li
        v-for="item in listData"
        :key="item"
        class="list-item"
      >
        {{ item }}
      </li>
    </ul>
  </div>
</template>

<script>
  export default {
    props: {
      icon: {
        type: String,
        required: true,
      },
      title: {
        type: String,
        default: '',
      },
      mark: {
        type: Boolean,
        default: false,
      },
      list: {
        type: [String, Array],
        default: '',
      },
    },
    computed: {
      listData() {
        if (this.list && typeof this.list === 'string') {
          return [this.list];
        }
        if (Array.isArray(this.list)) {
          return this.list;
        }
        return [];
      },
    },
  };
</script>
