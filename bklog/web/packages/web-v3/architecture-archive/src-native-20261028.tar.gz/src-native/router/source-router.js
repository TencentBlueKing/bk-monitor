import { unref } from 'vue';
const adapters = new WeakMap();
// V2 business hooks expose currentRoute as the route object. Preserve that
// contract while Vue Router 4 owns its reactive currentRoute Ref internally.
export function asSourceRouter(router) {
  let adapter = adapters.get(router);
  if (!adapter) {
    adapter = new Proxy(router, {
      get(target, key) {
        return key === 'currentRoute' ? unref(target.currentRoute) : Reflect.get(target, key, target);
      },
    });
    adapters.set(router, adapter);
  }
  return adapter;
}
