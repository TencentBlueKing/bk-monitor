<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
  import { computed, ref, watch } from 'vue';
  import { useRoute } from 'vue-router';

  import logo from './assets/logo.svg';
  import { apiGet } from './api/client';

  const route = useRoute();
  const bizName = ref('');
  const bizMark = ref('');
  const menus = [
    { id: 'retrieve', label: '检索' },
    { id: 'monitor', label: '监控策略' },
    { id: 'dashboard', label: '仪表盘' },
    { id: 'manage', label: '管理' },
  ];

  const active = computed(() => {
    const path = route.path;
    if (path.startsWith('/manage')) return 'manage';
    if (path.startsWith('/dashboard')) return 'dashboard';
    if (path.startsWith('/monitor')) return 'monitor';
    return 'retrieve';
  });
  const bizId = computed(() => String(route.query.bizId || route.query.bk_biz_id || ''));
  const isRetrieve = computed(() => active.value === 'retrieve' && String(route.name || '').includes('retrieve') || route.name === 'retrieve' || route.name === 'monitor-apm-log' || route.name === 'monitor-trace-log');

  function target(id: string) {
    if (id === 'monitor') return { name: 'monitor', query: route.query };
    if (id === 'dashboard') return { name: 'home', query: route.query };
    if (id === 'manage') return { name: 'manage', query: route.query };
    return {
      name: 'retrieve',
      params: route.params.indexId ? { indexId: route.params.indexId } : {},
      query: route.query,
    };
  }

  watch(bizId, async id => {
    if (!id) return;
    try {
      const data = await apiGet('/meta/spaces/mine/');
      const spaceUid = String(route.query.spaceUid || route.query.space_uid || '');
      const matched = (Array.isArray(data) ? data : []).find(item => item.space_uid === spaceUid)
        || (Array.isArray(data) ? data : []).find(item => String(item.bk_biz_id) === id);
      bizName.value = matched?.space_name || id;
      bizMark.value = bizName.value.slice(0, 1).toLocaleUpperCase();
    } catch {
      bizName.value = id;
    }
  }, { immediate: true });
</script>

<template>
  <div
    class="shell"
    data-testid="web-v3-shell"
  >
    <header class="topbar">
      <div class="brand">
        <img class="logo" :src="logo" alt="日志平台">
        <span>日志平台</span>
        <span
          v-if="bizName"
          class="biz"
        >
          <i>{{ bizMark }}</i>
          {{ bizName }}
        </span>
      </div>
      <nav class="top-nav">
        <router-link
          v-for="menu in menus"
          :key="menu.id"
          :to="target(menu.id)"
          :class="{ active: active === menu.id }"
        >
          {{ menu.label }}
        </router-link>
      </nav>
    </header>
    <main :class="['shell-main', { 'is-retrieve': isRetrieve }]">
      <router-view />
    </main>
  </div>
</template>
