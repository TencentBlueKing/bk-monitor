<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
const route = useRoute();
const router = useRouter();
const frame = ref<HTMLIFrameElement>();
const error = ref('');
const ready = ref(false);
const original = computed(() => router.resolve({ name: 'retrieve', params: { indexId: route.params.indexId }, query: route.query }));
const src = computed(() => `${import.meta.env.BASE_URL}legacy-v1/index.html#${original.value.fullPath}`);
function returnToV3() { router.push(original.value.fullPath); }
function receive(event: MessageEvent) {
  if (event.origin !== location.origin || event.source !== frame.value?.contentWindow) return;
  const data = event.data;
  if (data?.source === 'bklog-legacy-v1' && data.version === 1) {
    if (data.type === 'ready') ready.value = true;
    if (data.type === 'return-to-v3') returnToV3();
    if (data.type === 'auth-required') error.value = '登录已过期，请重新登录后重试';
  }
  // Compatibility adapter for the immutable published V1 message contract.
  if (data?.source === 'vue2-container' && data.type === 'sync-route-params') {
    const payload = data.payload;
    if (!payload || typeof payload !== 'object') return;
    const target = router.resolve({ name: payload.swtichVersion ? 'retrieve' : 'legacy-retrieve',
      params: { indexId: payload.params?.indexId || route.params.indexId }, query: { ...route.query, ...payload.query } });
    router.replace(target.fullPath);
  }
}
onMounted(() => window.addEventListener('message', receive));
onBeforeUnmount(() => window.removeEventListener('message', receive));
</script>
<template>
  <section class="legacy-retrieve">
    <div class="legacy-banner"><span>封版检索</span><button type="button" @click="returnToV3">返回新版</button><span v-if="!ready">加载中</span><span v-if="error" role="alert">{{ error }}</span></div>
    <iframe ref="frame" :src="src" title="封版 V1 日志检索" class="legacy-frame" />
  </section>
</template>
<style scoped>
.legacy-retrieve { display: flex; flex-direction: column; height: 100%; }
.legacy-banner { display: flex; align-items: center; gap: 16px; padding: 8px 16px; border-bottom: 1px solid #dcdee5; }
.legacy-frame { width: 100%; flex: 1; min-height: 600px; border: 0; }
</style>
