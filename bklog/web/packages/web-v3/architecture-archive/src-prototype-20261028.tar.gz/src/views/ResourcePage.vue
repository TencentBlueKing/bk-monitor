<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
  import { computed, ref, watch } from 'vue';
  import { useRoute } from 'vue-router';

  import { apiGet } from '../api/client';
  import { buildFeatureQuery, resolveFeature, toRows } from '../features/query.mjs';

  const route = useRoute();
  const rows = ref<Record<string, unknown>[]>([]);
  const loading = ref(false);
  const error = ref('');

  const title = computed(() => String(route.meta.title || route.name || ''));
  const columns = computed(() => {
    const sample = rows.value[0] || {};
    const preferred = ['collector_config_name', 'index_set_name', 'name', 'title', 'policy_name', 'status'];
    const keys = preferred.filter(key => key in sample);
    Object.keys(sample).forEach(key => {
      const value = sample[key];
      if (keys.length >= 6 || keys.includes(key) || value && typeof value === 'object') return;
      keys.push(key);
    });
    return keys;
  });

  function cell(row: Record<string, unknown>, key: string) {
    const value = row[key];
    if (value == null) return '';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }

  async function load() {
    const feature = resolveFeature(String(route.name || ''));
    if (feature.kind !== 'resource' || !feature.url) {
      rows.value = [];
      return;
    }
    loading.value = true;
    error.value = '';
    const spaceUid = String(route.query.spaceUid || route.query.space_uid || '');
    const bizId = String(route.query.bizId || route.query.bk_biz_id || '');
    try {
      const data = await apiGet(feature.url, buildFeatureQuery(feature, {
        bizId,
        spaceUid,
        params: route.params,
      }), { spaceUid });
      rows.value = toRows(data);
    } catch (err) {
      rows.value = [];
      error.value = err instanceof Error ? err.message : String(err);
    } finally {
      loading.value = false;
    }
  }

  watch(() => route.fullPath, load, { immediate: true });
</script>

<template>
  <section data-testid="resource-page">
    <h1>{{ title }}</h1>
    <p
      v-if="loading"
      class="page-summary"
    >
      加载中
    </p>
    <p
      v-if="error"
      class="page-error"
    >
      {{ error }}
    </p>
    <p
      v-else-if="!loading"
      class="page-summary"
    >
      {{ rows.length }} 条
    </p>
    <table v-if="columns.length">
      <thead>
        <tr>
          <th
            v-for="key in columns"
            :key="key"
          >
            {{ key }}
          </th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(row, index) in rows"
          :key="index"
        >
          <td
            v-for="key in columns"
            :key="key"
          >
            {{ cell(row, key) }}
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>
