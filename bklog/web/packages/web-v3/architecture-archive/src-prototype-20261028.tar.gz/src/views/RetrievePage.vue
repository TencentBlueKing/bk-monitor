<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
  import { computed, onBeforeUnmount, ref, watch } from 'vue';
  import { Button, Input, Popup, Select, Empty } from 'tdesign-vue-next';
  import RetrieveLogDetail from '../components/RetrieveLogDetail.vue';
  import RetrieveTimeRange from '../components/RetrieveTimeRange.vue';
  import { ConditionOperator } from '../features/condition-operator';
  import { DateRange, type DateValue } from '@blueking/date-picker';
  import { toSearchTimeRange, readTimePreference } from '../features/time-range.mjs';
  import RetrieveAutoRefresh from '../components/RetrieveAutoRefresh.vue';
  import { useRoute, useRouter } from 'vue-router';

  import { apiGet, apiPost } from '../api/client';
  import {
    buildAddition,
    buildClusterQuery,
    buildFieldSidebar,
    buildRetrieveQuery,
    buildSortList,
    clusterView,
    colorizeLog,
    flattenIndexSets,
    histogramInterval,
    highlightLog,
    nextSortOrder,
    toggleDisplayField,
  } from '../features/query.mjs';

  interface LogField {
    field_name: string;
    field_alias?: string;
    field_type?: string;
    field_operator?: Array<string | { operator: string; label?: string }>;
    is_built_in?: boolean;
  }

  interface SearchCondition {
    field: string;
    operator: string;
    value: string[];
  }

  interface TrendBucket {
    key: number;
    doc_count: number;
  }

  const route = useRoute();
  const router = useRouter();
  const draggedField = ref('');
  const formatJson = ref(false);
  const highlightInput = ref('');
  const highlightTerms = ref<string[]>([]);
  const caseSensitive = ref(false);
  const regexHighlight = ref(false);
  const wholeWord = ref(false);
  const highlightError = ref('');
  function addHighlight() {
    const text = highlightInput.value.trim();
    highlightError.value = '';
    if (!text) return;
    if (regexHighlight.value) {
      try { new RegExp(text); } catch { highlightError.value = '无效的正则表达式'; return; }
    }
    if (!highlightTerms.value.includes(text)) highlightTerms.value.push(text);
    highlightInput.value = '';
  }
  function logParts(text: string) {
    return highlightLog(text, highlightTerms.value, { caseSensitive: caseSensitive.value, regex: regexHighlight.value, wholeWord: wholeWord.value })
      .flatMap(part => part.highlighted ? [{ text: part.text, kind: 'page-highlight' }] : colorizeLog(part.text));
  }
  function moveField(target: string) {
    const names = [...displayNames.value];
    const from = names.indexOf(draggedField.value);
    const to = names.indexOf(target);
    if (from < 0 || to < 0) return;
    names.splice(from, 1);
    names.splice(to, 0, draggedField.value);
    displayNames.value = names;
    draggedField.value = '';
  }
  function logText(value: string) {
    if (!formatJson.value) return value;
    try { return JSON.stringify(JSON.parse(value), null, 2); } catch { return value; }
  }
  const keyword = ref('');
  const searchMode = ref('ui');
  const ipChooser = ref({});
  const showHistory = ref(false);
  const historyLoading = ref(false);
  const historyError = ref('');
  const historyQuery = ref('');
  interface HistoryRecord {
    id: string | number;
    query_string: string;
    created_at?: string;
    search_mode?: string;
    params?: { keyword?: string; addition?: SearchCondition[]; search_mode?: string; ip_chooser?: Record<string, unknown> };
  }
  const historyRecords = ref<HistoryRecord[]>([]);
  const filteredHistory = computed(() => historyRecords.value.filter(item =>
    String(item.query_string || '').toLowerCase().includes(historyQuery.value.trim().toLowerCase())));
  const trendError = ref('');
  let contextVersion = 0;
  let searchVersion = 0;
  let historyVersion = 0;
  let clusterVersion = 0;
  onBeforeUnmount(() => { contextVersion++; searchVersion++; historyVersion++; clusterVersion++; });

  async function openHistory() {
    showHistory.value = true;
    historyLoading.value = true;
    historyError.value = '';
    historyQuery.value = '';
    historyRecords.value = [];
    const version = ++historyVersion;
    try {
      const data = await apiGet(`/search/index_set/${indexId.value}/history/`, {}, { spaceUid: spaceUid.value });
      if (version !== historyVersion) return;
      historyRecords.value = (Array.isArray(data) ? data : []).filter(item => item.query_string !== '*');
    } catch (err) {
      if (version === historyVersion) historyError.value = err instanceof Error ? err.message : String(err);
    } finally {
      if (version === historyVersion) historyLoading.value = false;
    }
  }

  function restoreHistory(item: HistoryRecord) {
    const params = item.params || {};
    keyword.value = params.keyword || '';
    conditions.value = (params.addition || []).map((condition: SearchCondition) => ({ ...condition, value: [...condition.value] }));
    searchMode.value = params.search_mode || item.search_mode || 'ui';
    ipChooser.value = params.ip_chooser || {};
    showHistory.value = false;
    search();
  }
  const indexSets = ref<{ index_set_id: string; index_set_name: string; label?: string }[]>([]);
  const fields = ref<LogField[]>([]);
  const displayNames = ref<string[]>(['dtEventTimeStamp', 'serverIp', 'log']);
  const rows = ref<Record<string, unknown>[]>([]);
  const buckets = ref<TrendBucket[]>([]);
  const total = ref(0);
  const loadingMore = ref(false);
  const moreError = ref('');
  let lastQuery: ReturnType<typeof buildRetrieveQuery> | null = null;
  async function loadMore() {
    if (!lastQuery || loading.value || loadingMore.value || rows.value.length >= total.value) return;
    const version = searchVersion;
    loadingMore.value = true;
    moreError.value = '';
    try {
      const data = await apiPost(`/search/index_set/${indexId.value}/search/`, { ...lastQuery, begin: rows.value.length }, { spaceUid: spaceUid.value });
      if (version !== searchVersion) return;
      const nextRows = Array.isArray(data?.origin_log_list) ? data.origin_log_list : [];
      rows.value = [...rows.value, ...nextRows];
      if (!nextRows.length) moreError.value = '没有获取到更多日志，请重新查询';
    } catch (err) {
      if (version === searchVersion) moreError.value = err instanceof Error ? err.message : String(err);
    } finally {
      if (version === searchVersion) loadingMore.value = false;
    }
  }
  const took = ref(0);
  const loading = ref(false);
  const error = ref('');
  const showNumber = ref(false);
  const wrapLine = ref(false);
  const resultTab = ref('origin');
  const fieldQuery = ref('');
  const selectedTime = ref<DateValue>(readTimePreference(localStorage) as DateValue);
  const timeFormat = ref(localStorage.getItem('SEARCH_DEFAULT_TIME_FORMAT') || 'YYYY-MM-DD HH:mm:ss');
  const timezone = ref(Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Shanghai');
  function searchTimeRange() { return toSearchTimeRange(new DateRange(selectedTime.value, timeFormat.value, timezone.value)); }
  function timeChanged() {
    router.replace({ query: { ...route.query, start_time: String(selectedTime.value[0]), end_time: String(selectedTime.value[1]), timezone: timezone.value, format: timeFormat.value } });
    search();
  }
  const detailVisible = ref(false);
  const detailRow = ref<Record<string, unknown> | null>(null);
  const conditions = ref<SearchCondition[]>([]);
  const conditionField = ref('log');
  const conditionOperator = ref('contains');
  const conditionValue = ref('');
  const patterns = ref<Record<string, unknown>[]>([]);
  const clusterError = ref('');
  const fieldConfig = ref<{ name?: string; is_active?: boolean }[]>([]);
  const defaultSort = ref<string[][]>([]);
  const sortOrder = ref<string | null>(null);
  const contentType = ref<'table' | 'original'>('table');
  const expandedRows = ref<number[]>([]);
  const expandedGroups = ref<string[]>([]);
  const showBuiltIn = ref(false);
  const showAllOptional = ref(false);
  const showCondition = ref(false);

  const spaceUid = computed(() => String(route.query.spaceUid || route.query.space_uid || ''));
  const bizId = computed(() => String(route.query.bizId || route.query.bk_biz_id || ''));
  const indexId = computed(() => String(route.params.indexId || ''));
  const displayFields = computed(() => displayNames.value.map(name => fields.value.find(field => field.field_name === name) || { field_name: name }));
  const sidebar = computed(() => buildFieldSidebar(fields.value, displayNames.value));
  const optionalFields = computed(() => filterTree(sidebar.value.optional));
  const builtInFields = computed(() => filterFields(sidebar.value.builtIn));
  const visibleOptional = computed(() => (showAllOptional.value || fieldQuery.value.trim() ? optionalFields.value : optionalFields.value.slice(0, 10)));
  const maxCount = computed(() => Math.max(1, ...buckets.value.map(bucket => bucket.doc_count)));
  const trendTicks = computed(() => {
    const top = Math.max(1, maxCount.value);
    const step = top <= 10 ? 2 : Math.ceil(top / 5);
    const ticks: number[] = [];
    for (let value = Math.ceil(top / step) * step; value >= 0; value -= step) ticks.push(value);
    return ticks;
  });
  const clusterMode = computed(() => clusterView(fieldConfig.value, fields.value));
  const sortLabel = computed(() => (sortOrder.value === 'asc' ? '当前升序' : sortOrder.value === 'desc' ? '当前降序' : '点击切换排序'));

  const operatorOptions = computed(() => {
    const field = fields.value.find(item => item.field_name === conditionField.value);
    const options = (field?.field_operator || []).map(item => (
      typeof item === 'string' ? { operator: item, label: item } : { operator: item.operator, label: item.label || item.operator }
    ));
    return options;
  });

  function filterFields(list: LogField[]) {
    const text = fieldQuery.value.trim().toLowerCase();
    if (!text) return list;
    return list.filter(field => field.field_name.toLowerCase().includes(text));
  }

  function filterTree(list: Array<LogField & { children?: LogField[] }>) {
    const text = fieldQuery.value.trim().toLowerCase();
    if (!text) return list;
    return list.flatMap(field => {
      const children = (field.children || []).filter(child => child.field_name.toLowerCase().includes(text));
      if (field.field_name.toLowerCase().includes(text) || children.length) {
        return [{ ...field, children: children.length ? children : field.children }];
      }
      return [];
    });
  }

  function pad(value: number) {
    return String(value).padStart(2, '0');
  }

  function formatTime(value: unknown, withDate = true) {
    const parsed = parseTime(value);
    if (!parsed) return value == null ? '' : String(value);
    const clock = `${pad(parsed.date.getHours())}:${pad(parsed.date.getMinutes())}:${pad(parsed.date.getSeconds())}`;
    if (!withDate) return `${pad(parsed.date.getHours())}:${pad(parsed.date.getMinutes())}`;
    return `${parsed.date.getFullYear()}-${pad(parsed.date.getMonth() + 1)}-${pad(parsed.date.getDate())} ${clock}`;
  }

  function parseTime(value: unknown) {
    const numberValue = Number(value);
    if (!Number.isFinite(numberValue)) return null;
    return { date: new Date(numberValue > 1e12 ? numberValue : numberValue * 1000), milliseconds: numberValue > 1e12 };
  }

  function preciseTime(value: unknown) {
    const parsed = parseTime(value);
    if (!parsed) return '';
    const base = formatTime(value);
    const fraction = String(parsed.date.getMilliseconds()).padStart(3, '0');
    return `[${base}.${fraction}]`;
  }

  function cellText(row: Record<string, unknown>, field: string) {
    const value = row[field];
    if (field === 'dtEventTimeStamp' || field === 'time') return formatTime(value);
    if (value == null) return '';
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }

  let indexListVersion = 0;
  onBeforeUnmount(() => indexListVersion++);
  async function loadIndexSets() {
    const version = ++indexListVersion;
    if (!spaceUid.value) { indexSets.value = []; return; }
    const data = await apiGet('/search/index_set/', { space_uid: spaceUid.value, is_group: true }, { spaceUid: spaceUid.value });
    if (version !== indexListVersion) return;
    indexSets.value = flattenIndexSets(Array.isArray(data) ? data : []);
  }

  async function loadFields(version: number) {
    if (!indexId.value) return;
    const data = await apiGet(`/search/index_set/${indexId.value}/fields/`, { bk_biz_id: bizId.value }, { spaceUid: spaceUid.value });
    if (version !== contextVersion) return;
    fields.value = Array.isArray(data?.fields) ? data.fields : [];
    fieldConfig.value = Array.isArray(data?.config) ? data.config : [];
    defaultSort.value = Array.isArray(data?.default_sort_list) && data.default_sort_list.length
      ? data.default_sort_list
      : (Array.isArray(data?.sort_list) ? data.sort_list : []);
    if (Array.isArray(data?.display_fields) && data.display_fields.length) displayNames.value = data.display_fields;
  }

  async function search() {
    const version = ++searchVersion;
    clusterVersion++;
    expandedRows.value = [];
    loadingMore.value = false;
    moreError.value = '';
    lastQuery = null;
    detailVisible.value = false;
    trendError.value = '';
    total.value = 0;
    rows.value = [];
    buckets.value = [];
    if (!indexId.value) {
      rows.value = [];
      buckets.value = [];
      return;
    }
    loading.value = true;
    error.value = '';
    const range = searchTimeRange();
    const query = buildRetrieveQuery({
      bizId: bizId.value,
      spaceUid: spaceUid.value,
      keyword: keyword.value,
      searchMode: searchMode.value,
      ipChooser: ipChooser.value,
      timezone: timezone.value,
      startTime: range.start_time,
      endTime: range.end_time,
      addition: conditions.value,
      sortList: buildSortList(defaultSort.value, sortOrder.value),
    });
    try {
      const [searchResult, chartResult] = await Promise.allSettled([
        apiPost(`/search/index_set/${indexId.value}/search/`, query, { spaceUid: spaceUid.value }),
        apiPost(`/search/index_set/${indexId.value}/aggs/date_histogram/`, {
          ...query,
          time_range: 'customized',
          interval: histogramInterval(range.end_time - range.start_time),
        }, { spaceUid: spaceUid.value }),
      ]);
      if (version !== searchVersion) return;
      if (searchResult.status === 'rejected') throw searchResult.reason;
      const searchData = searchResult.value;
      const chartData = chartResult.status === 'fulfilled' ? chartResult.value : null;
      if (chartResult.status === 'rejected') trendError.value = chartResult.reason instanceof Error ? chartResult.reason.message : String(chartResult.reason);
      lastQuery = query;
      rows.value = Array.isArray(searchData?.origin_log_list) ? searchData.origin_log_list : [];
      total.value = Number(searchData?.total ?? rows.value.length);
      took.value = Number(searchData?.took || 0);
      buckets.value = chartData?.aggs?.group_by_histogram?.buckets || [];
      if (resultTab.value === 'cluster') await loadCluster(query);
    } catch (err) {
      if (version !== searchVersion) return;
      rows.value = [];
      buckets.value = [];
      error.value = err instanceof Error ? err.message : String(err);
    } finally {
      if (version === searchVersion) loading.value = false;
    }
  }

  async function loadCluster(query?: ReturnType<typeof buildRetrieveQuery>) {
    if (!indexId.value) return;
    const range = searchTimeRange();
    const searchQuery = query || buildRetrieveQuery({
      bizId: bizId.value,
      spaceUid: spaceUid.value,
      keyword: keyword.value,
      searchMode: searchMode.value,
      ipChooser: ipChooser.value,
      timezone: timezone.value,
      startTime: range.start_time,
      endTime: range.end_time,
      addition: conditions.value,
      sortList: buildSortList(defaultSort.value, sortOrder.value),
    });
    const version = ++clusterVersion;
    clusterError.value = '';
    try {
      const data = await apiPost(`/pattern/${indexId.value}/search/`, buildClusterQuery(searchQuery), { spaceUid: spaceUid.value });
      if (version !== clusterVersion) return;
      patterns.value = Array.isArray(data) ? data : [];
    } catch (err) {
      if (version !== clusterVersion) return;
      patterns.value = [];
      clusterError.value = err instanceof Error ? err.message : String(err);
    }
  }

  function addCondition() {
    if (!operatorOptions.value.some(item => item.operator === conditionOperator.value)) return;
    const next = buildAddition(conditionField.value, conditionOperator.value, conditionValue.value);
    if (!next) return;
    const fieldType = fields.value.find(field => field.field_name === next.field)?.field_type;
    const converted = new ConditionOperator({ ...next, field_type: fieldType }).getRequestParam();
    conditions.value = [...conditions.value, converted];
    conditionValue.value = '';
    search();
  }

  function removeCondition(index: number) {
    conditions.value = conditions.value.filter((_, itemIndex) => itemIndex !== index);
    search();
  }

  function toggleField(fieldName: string) {
    displayNames.value = toggleDisplayField(displayNames.value, fieldName);
  }

  function toggleGroup(fieldName: string) {
    expandedGroups.value = expandedGroups.value.includes(fieldName)
      ? expandedGroups.value.filter(name => name !== fieldName)
      : [...expandedGroups.value, fieldName];
  }

  function toggleRow(index: number) {
    detailRow.value = rows.value[index];
    detailVisible.value = true;
  }

  function cycleSort() {
    sortOrder.value = nextSortOrder(sortOrder.value);
    search();
  }

  function openCluster() {
    resultTab.value = 'cluster';
    clusterError.value = '';
    if (clusterMode.value === 'search') loadCluster();
    else patterns.value = [];
  }

  function addFieldFilter(fieldName: string, value: unknown) {
    const field = fields.value.find(item => item.field_name === fieldName);
    const operators = (field?.field_operator || []).map(item => (typeof item === 'string' ? item : item.operator));
    const operator = operators.find(item => item === '=')
      || operators.find(item => item === 'contains match phrase')
      || operators[0];
    if (!operator) return;
    const next = buildAddition(fieldName, operator, value);
    if (!next) return;
    const fieldType = fields.value.find(field => field.field_name === next.field)?.field_type;
    const converted = new ConditionOperator({ ...next, field_type: fieldType }).getRequestParam();
    conditions.value = [...conditions.value, converted];
    search();
  }

  function rowEntries(row: Record<string, unknown>) {
    return Object.entries(row).filter(([key]) => key !== '__data_label');
  }

  function typeMark(type?: string) {
    if (type === 'text') return 'T';
    if (type === 'keyword') return 'K';
    if (type === 'date') return 'D';
    if (type === 'integer' || type === 'long') return '#';
    if (type === 'boolean') return 'B';
    if (type === 'object') return '{}';
    return '';
  }

  function changeIndex(event: Event) {
    const value = (event.target as HTMLSelectElement).value;
    router.push({ name: 'retrieve', params: { indexId: value }, query: route.query });
  }

  watch(() => [spaceUid.value, bizId.value], () => {
    loadIndexSets().catch(err => {
      error.value = err instanceof Error ? err.message : String(err);
    });
  }, { immediate: true });

  watch(operatorOptions, options => {
    if (!options.some(item => item.operator === conditionOperator.value)) {
      conditionOperator.value = options[0]?.operator || '';
    }
  });

  watch(() => [route.query.start_time, route.query.end_time, route.query.timezone, route.query.format], () => {
    const { start_time, end_time, timezone: zone, format } = route.query;
    if (typeof start_time !== 'string' || typeof end_time !== 'string') return;
    const value: DateValue = [start_time, end_time];
    const nextZone = typeof zone === 'string' ? zone : timezone.value;
    const nextFormat = typeof format === 'string' ? format : timeFormat.value;
    try {
      toSearchTimeRange(new DateRange(value, nextFormat, nextZone));
      const changed = String(selectedTime.value[0]) !== start_time || String(selectedTime.value[1]) !== end_time || timezone.value !== nextZone || timeFormat.value !== nextFormat;
      selectedTime.value = value;
      timezone.value = nextZone;
      timeFormat.value = nextFormat;
      if (changed && fields.value.length) search();
    } catch {
      error.value = '链接中的时间范围或时区无效';
    }
  }, { immediate: true });

  watch(() => [indexId.value, spaceUid.value, bizId.value], async () => {
    const version = ++contextVersion;
    searchVersion++;
    clusterVersion++;
    historyVersion++;
    loading.value = false;
    loadingMore.value = false;
    moreError.value = '';
    lastQuery = null;
    detailVisible.value = false;
    showHistory.value = false;
    fields.value = [];
    fieldConfig.value = [];
    defaultSort.value = [];
    sortOrder.value = null;
    conditions.value = [];
    ipChooser.value = {};
    rows.value = [];
    buckets.value = [];
    total.value = 0;
    error.value = '';
    try {
      await loadFields(version);
      if (version === contextVersion) await search();
    } catch (err) {
      if (version === contextVersion) error.value = err instanceof Error ? err.message : String(err);
    }
  }, { immediate: true });
</script>

<template>
  <section
    class="retrieve"
    data-testid="retrieve-page"
  >
    <div class="subbar">
      <div class="mode-tabs">
        <button
          class="active"
          type="button"
        >
          常规检索
        </button>
        <button type="button">场景化检索</button>
      </div>
      <Select class="index-select" :value="indexId" filterable :clearable="false" :options="indexSets.map(item => ({ value: item.index_set_id, label: item.label || item.index_set_name }))" placeholder="请选择索引集" @change="value => router.push({ name: 'retrieve', params: { indexId: String(value) }, query: route.query })" />
      <Popup v-model:visible="showHistory" trigger="click" placement="bottom-left" @visible-change="visible => { if (visible) openHistory(); }">
        <Button variant="text">历史查询</Button>
        <template #content>
          <section class="history-panel" aria-label="历史查询">
            <Input v-model="historyQuery" placeholder="请输入关键字" clearable />
            <p v-if="historyLoading">加载中</p>
            <p v-else-if="historyError" role="alert">{{ historyError }} <Button variant="text" @click="openHistory">重试</Button></p>
            <ul v-else>
              <li v-for="item in filteredHistory" :key="item.id">
                <button type="button" :title="item.created_at" @click="restoreHistory(item)">
                  <span>{{ item.params?.search_mode || item.search_mode || 'ui' }}</span> {{ item.query_string }}
                </button>
              </li>
              <li v-if="!filteredHistory.length">暂无历史记录</li>
            </ul>
          </section>
        </template>
      </Popup>
      <RetrieveTimeRange v-model="selectedTime" v-model:timezone="timezone" v-model:format="timeFormat" @change="timeChanged" @timezone-change="timeChanged" />
      <RetrieveAutoRefresh @refresh="search" />
      <router-link :to="{ name: 'legacy-retrieve', params: { indexId }, query: route.query }">回到旧版</router-link>
    </div>

    <div class="searchbar">
      <select v-model="searchMode" class="ui-tag" aria-label="查询模式">
        <option value="ui">UI</option>
        <option value="sql">SQL</option>
      </select>
      <button
        class="add-condition"
        type="button"
        @click="showCondition = !showCondition"
      >
        + 添加条件
      </button>
      <template v-if="showCondition && searchMode === 'ui'">
        <select
          v-model="conditionField"
          class="condition-field"
        >
          <option
            v-for="field in fields"
            :key="field.field_name"
            :value="field.field_name"
          >
            {{ field.field_name }}
          </option>
        </select>
        <select
          v-model="conditionOperator"
          class="condition-operator"
        >
          <option
            v-for="operator in operatorOptions"
            :key="operator.operator"
            :value="operator.operator"
          >
            {{ operator.label }}
          </option>
        </select>
        <input
          v-model="conditionValue"
          class="condition-value"
          placeholder="条件值"
          @keydown.enter="addCondition"
        >
      </template>
      <input
        v-model="keyword"
        class="keyword"
        placeholder="输入检索内容"
        @keydown.enter="search"
      >
      <span class="ai-mode">AI 模式</span>
      <button
        class="query-btn"
        type="button"
        data-testid="retrieve-search"
        :disabled="loading"
        @click="search"
      >
        查询
      </button>
    </div>

    <div
      v-if="conditions.length"
      class="condition-list"
    >
      <button
        v-for="(condition, index) in conditions"
        :key="`${condition.field}-${index}`"
        type="button"
        @click="removeCondition(index)"
      >
        {{ condition.field }} {{ condition.operator }} {{ condition.value[0] }} ×
      </button>
    </div>

    <div class="result-tabs">
      <button
        :class="{ active: resultTab === 'origin' }"
        type="button"
        @click="resultTab = 'origin'"
      >
        原始日志
      </button>
      <button
        :class="{ active: resultTab === 'cluster' }"
        type="button"
        @click="openCluster"
      >
        日志聚类
      </button>
    </div>

    <div class="result-body">
      <aside class="fields">
        <input
          v-model="fieldQuery"
          class="field-search"
          placeholder="搜索字段名"
        >
        <h3>显示字段</h3>
        <ul>
          <li
            v-for="field in displayFields"
            :key="field.field_name"
            draggable="true"
            @dragstart="draggedField = field.field_name"
            @dragover.prevent
            @drop.prevent="moveField(field.field_name)"
            @dragend="draggedField = ''"
          >
            <button
              type="button"
              @click="toggleField(field.field_name)"
            >
              <i>{{ typeMark(field.field_type) }}</i>{{ field.field_name }}
            </button>
          </li>
        </ul>
        <h3>可选字段</h3>
        <ul>
          <li
            v-for="field in visibleOptional"
            :key="field.field_name"
          >
            <button
              v-if="field.children?.length"
              type="button"
              @click="toggleGroup(field.field_name)"
            >
              <i>{{ typeMark('object') }}</i>{{ field.field_name }} ({{ field.children.length }})
            </button>
            <button
              v-else
              type="button"
              @click="toggleField(field.field_name)"
            >
              <i>{{ typeMark(field.field_type) }}</i>{{ field.field_name }}
            </button>
            <ul v-if="field.children?.length && (expandedGroups.includes(field.field_name) || fieldQuery)">
              <li
                v-for="child in field.children"
                :key="child.field_name"
              >
                <button
                  type="button"
                  @click="toggleField(child.field_name)"
                >
                  <i>{{ typeMark(child.field_type) }}</i>{{ child.field_name.split('.').pop() }}
                </button>
              </li>
            </ul>
          </li>
        </ul>
        <button
          v-if="optionalFields.length > 10"
          class="expand-all"
          type="button"
          @click="showAllOptional = !showAllOptional"
        >
          {{ showAllOptional ? '收起' : '展开全部' }}
        </button>
        <h3>
          <button
            type="button"
            @click="showBuiltIn = !showBuiltIn"
          >
            {{ showBuiltIn ? '▾' : '▸' }} 内置字段
          </button>
        </h3>
        <ul v-if="showBuiltIn">
          <li
            v-for="field in builtInFields"
            :key="field.field_name"
          >
            <button
              type="button"
              @click="toggleField(field.field_name)"
            >
              <i>{{ typeMark(field.field_type) }}</i>{{ field.field_name }}
            </button>
          </li>
        </ul>
      </aside>

      <div class="result-main">
        <p
          v-if="error"
          class="page-error"
        >
          {{ error }}
        </p>
        <template v-else-if="resultTab === 'origin'">
          <div class="trend">
            <div class="trend-head">
              <strong>总趋势</strong>
              <span>（找到 {{ total }} 条结果，用时 {{ took }} 毫秒）</span>
              <em>汇聚周期 : auto</em>
            </div>
            <p v-if="trendError" role="alert">趋势加载失败：{{ trendError }}</p>
            <div
              v-else
              class="trend-chart"
              data-testid="retrieve-trend"
            >
              <div class="trend-axis">
                <span
                  v-for="tick in trendTicks"
                  :key="tick"
                >{{ tick }}</span>
              </div>
              <div class="trend-bars">
                <div
                  v-for="bucket in buckets"
                  :key="bucket.key"
                  class="trend-col"
                  :title="`${formatTime(bucket.key)} ${bucket.doc_count}`"
                >
                  <i :style="{ height: `${Math.max(2, (bucket.doc_count / trendTicks[0]) * 72)}px` }" />
                  <span>{{ formatTime(bucket.key, false) }}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="table-tools">
            <button
              class="seg"
              :class="{ active: contentType === 'original' }"
              type="button"
              @click="contentType = 'original'"
            >
              原始
            </button>
            <button
              class="seg"
              :class="{ active: contentType === 'table' }"
              type="button"
              @click="contentType = 'table'"
            >
              表格
            </button>
            <button
              class="text-btn"
              type="button"
              :title="sortLabel"
              data-testid="retrieve-sort"
              @click="cycleSort"
            >
              日志排序{{ sortOrder === 'asc' ? ' ↑' : sortOrder === 'desc' ? ' ↓' : '' }}
            </button>
            <label><input
              v-model="showNumber"
              type="checkbox"
            > 显示行号</label>
            <label><input v-model="formatJson" type="checkbox"> JSON 格式化</label>
            <label><input
              v-model="wrapLine"
              type="checkbox"
            > 换行</label>
          </div>
          <p v-if="loading" role="status">加载中</p>
          <div class="highlight-tools">
            <label>高亮 <input v-model="highlightInput" placeholder="输入后按 Enter..." @keydown.enter="addHighlight"></label>
            <label><input v-model="caseSensitive" type="checkbox">区分大小写</label>
            <label><input v-model="wholeWord" type="checkbox">全词</label>
            <label><input v-model="regexHighlight" type="checkbox">正则</label>
            <button v-for="term in highlightTerms" :key="term" type="button" @click="highlightTerms = highlightTerms.filter(item => item !== term)">{{ term }} ×</button>
            <span v-if="highlightError" role="alert">{{ highlightError }}</span>
          </div>
          <div class="log-scroll">
            <table
              class="log-table"
              data-testid="retrieve-log-table"
            >
              <thead>
                <tr>
                  <th class="expander" />
                  <th
                    v-if="showNumber"
                    class="line-no"
                  >
                    #
                  </th>
                  <template v-if="contentType === 'table'">
                    <th
                      v-for="field in displayFields"
                      :key="field.field_name"
                      :class="{ log: field.field_name === 'log', 'time-col': field.field_name === 'dtEventTimeStamp' || field.field_name === 'time' }"
                    >
                      {{ field.field_name }}
                    </th>
                  </template>
                  <template v-else>
                    <th class="time-col">dtEventTimeStamp</th>
                    <th class="log">log</th>
                  </template>
                </tr>
              </thead>
              <tbody>
                <tr v-if="!loading && !rows.length"><td :colspan="(showNumber ? 2 : 1) + (contentType === 'table' ? displayFields.length : 2)"><div class="retrieve-empty" role="status"><Empty description="检索无数据" /></div></td></tr>
                <template
                  v-for="(row, index) in rows"
                  :key="index"
                >
                  <tr>
                    <td class="expander">
                      <button
                        type="button"
                        @click="toggleRow(index)"
                      >
                        {{ expandedRows.includes(index) ? '▾' : '▸' }}
                      </button>
                    </td>
                    <td
                      v-if="showNumber"
                      class="line-no"
                    >
                      {{ index + 1 }}
                    </td>
                    <template v-if="contentType === 'table'">
                      <td
                        v-for="field in displayFields"
                        :key="field.field_name"
                        :class="{ log: field.field_name === 'log', wrap: wrapLine || formatJson, link: field.field_name !== 'log' && field.field_name !== 'dtEventTimeStamp' && field.field_name !== 'time', 'time-col': field.field_name === 'dtEventTimeStamp' || field.field_name === 'time' }"
                      >
                        <template v-if="field.field_name === 'dtEventTimeStamp' || field.field_name === 'time'">
                          {{ formatTime(row[field.field_name]) }}
                          <em>{{ preciseTime(row[field.field_name]) }}</em>
                        </template>
                        <button
                          v-else-if="field.field_name !== 'log'"
                          type="button"
                          @click="addFieldFilter(field.field_name, row[field.field_name])"
                        >
                          {{ cellText(row, field.field_name) }}
                        </button>
                        <template v-else>
                          <span
                            v-for="(part, partIndex) in logParts(logText(cellText(row, field.field_name)))"
                            :key="partIndex"
                            :class="part.kind"
                          >{{ part.text }}</span>
                        </template>
                      </td>
                    </template>
                    <template v-else>
                      <td class="time-col">{{ formatTime(row.dtEventTimeStamp) }} <em>{{ preciseTime(row.dtEventTimeStamp) }}</em></td>
                      <td
                        class="log"
                        :class="{ wrap: wrapLine || formatJson }"
                      >
                        <span
                          v-for="(part, partIndex) in logParts(formatJson ? JSON.stringify(row, null, 2) : JSON.stringify(row))"
                          :key="partIndex"
                          :class="part.kind"
                        >{{ part.text }}</span>
                      </td>
                    </template>
                  </tr>

                </template>
              </tbody>
            </table>
          </div>
          <div v-if="rows.length" class="result-pagination">
            <span>已加载 {{ rows.length }} / {{ total }} 条</span>
            <Button v-if="rows.length < total" size="small" :loading="loadingMore" :disabled="loading" @click="loadMore">加载更多</Button>
            <span v-else>已加载全部</span>
            <span v-if="moreError" role="alert">{{ moreError }}</span>
          </div>
        </template>
        <div
          v-else
          class="cluster-panel"
          data-testid="retrieve-cluster"
        >
          <div
            v-if="clusterMode === 'quick-open'"
            class="quick-cluster"
          >
            <h2>快速开启日志聚类</h2>
            <p>日志聚类可以通过智能分析算法，将相似度高的日志进行快速的汇聚分析，提取日志 Pattern 并进行展示</p>
            <h3>日志聚类的优势</h3>
            <p>1. 有利于发现日志中的规律和共性问题，方便从海量日志中排查问题，定位故障</p>
            <p>2. 可从海量日志中，提取共性部分同时保留独立信息以便于减少存储成本，最多可减少 10% 的存储成本</p>
            <p>3. 当版本变更时，可快速定位变更后新增问题</p>
          </div>
          <p
            v-else-if="clusterMode === 'empty'"
            class="page-error"
          >
            当前索引集不支持日志聚类设置
          </p>
          <p
            v-else-if="clusterError"
            class="page-error"
          >
            {{ clusterError }}
          </p>
          <p
            v-else
            class="trend-head"
          >
            日志聚类 · {{ patterns.length }} 条
          </p>
          <table
            v-if="clusterMode === 'search' && patterns.length"
            class="log-table"
          >
            <thead>
              <tr>
                <th>count</th>
                <th>percentage</th>
                <th class="log">pattern</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="(pattern, index) in patterns"
                :key="index"
              >
                <td>{{ pattern.count }}</td>
                <td>{{ Number(pattern.percentage || 0).toFixed(2) }}%</td>
                <td class="log">{{ pattern.pattern || pattern.origin_log || pattern.signature }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <RetrieveLogDetail v-model:visible="detailVisible" :row="detailRow" :filter-fields="fields.filter(field => field.field_operator?.length).map(field => field.field_name)" @filter="addFieldFilter" />
  </section>
</template>
