/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import { createRouter, createWebHashHistory, type RouteLocationGeneric, type RouteRecordRaw } from 'vue-router';

import { resolveFeature } from '../features/query.mjs';
import routes from './legacy-routes.json';
import LegacyRetrievePage from '../views/LegacyRetrievePage.vue';
import ExceptionPage from '../views/ExceptionPage.vue';
import ResourcePage from '../views/ResourcePage.vue';
import RetrievePage from '../views/RetrievePage.vue';

interface LegacyRoute {
  name: string;
  title: string;
  path: string;
}

const pages: Record<string, RouteRecordRaw['component']> = {
  search: RetrievePage,
  exception: ExceptionPage,
  resource: ResourcePage,
};

function componentFor(name: string) {
  return pages[resolveFeature(name).kind] || ResourcePage;
}

function redirectQuery(name: string) {
  return (to: RouteLocationGeneric) => ({ name, query: to.query });
}

const legacyRoutes = (routes as LegacyRoute[]).map((route): RouteRecordRaw => {
  if (route.name === 'manage') {
    return { path: route.path, name: route.name, redirect: redirectQuery('collection-item-list') };
  }
  if (route.name === 'dashboard') {
    return { path: route.path, name: route.name, redirect: redirectQuery('home') };
  }
  if (route.name === 'log-collection' || route.name === 'collection-item') {
    return { path: route.path, name: route.name, redirect: redirectQuery('collection-item-list') };
  }
  if (route.name === 'exception') {
    return { path: '/:pathMatch(.*)*', name: route.name, component: ExceptionPage, meta: { title: route.title } };
  }
  return {
    path: route.path,
    name: route.name,
    component: componentFor(route.name),
    meta: { title: route.title },
  };
});

export const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/', redirect: to => ({ name: 'retrieve', query: to.query }) },
    {
      path: '/monitor',
      name: 'monitor',
      component: ResourcePage,
      meta: { title: '监控策略' },
    },
    { path: '/legacy-retrieve/:indexId?', name: 'legacy-retrieve', component: LegacyRetrievePage, meta: { title: '封版检索' } },
    ...legacyRoutes,
  ],
});
