/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

// Only transport conversion belongs to the application. The shared date-picker parses dates.
/** @param {{startDate: {valueOf(): number}|null, endDate: {valueOf(): number}|null}} range */
export function toSearchTimeRange(range) {
 const start = Number(range.startDate?.valueOf());
 const end = Number(range.endDate?.valueOf());
 if (!range.startDate || !range.endDate || !Number.isFinite(start) || !Number.isFinite(end) || start > end) throw new Error('无效的检索时间范围');
 return { start_time: Math.floor(start / 1000), end_time: Math.floor(end / 1000) };
}
export function readTimePreference(storage) {
 try {
   const saved = JSON.parse(storage.getItem('SEARCH_DEFAULT_TIME') || 'null');
   if (Array.isArray(saved) && saved.length === 2 && saved.every(value => typeof value === 'string' && value.length)) return saved;
 } catch { /* Invalid preferences must not prevent application startup. */ }
 return ['now-15m', 'now'];
}
