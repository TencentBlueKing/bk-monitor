/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ConditionOperator } from './condition-operator.ts';
test('ported Vue2 operator preserves phrase, wildcard and multi-value conjunction semantics', () => {
 const make = extra => new ConditionOperator({field:'log', operator:'contains match phrase', value:['one','two'], field_type:'text', ...extra}).getRequestParam();
 assert.equal(make({relation:'OR',isInclude:false}).operator,'contains match phrase');
 assert.equal(make({relation:'AND',isInclude:false}).operator,'all contains match phrase');
 assert.equal(make({relation:'AND',isInclude:true}).operator,'&=~');
 assert.equal(make({relation:'OR',isInclude:true}).operator,'=~');
 assert.equal(make({relation:'AND',value:['one'],isInclude:false}).operator,'contains match phrase');
 assert.equal(make({field:'*',relation:'AND',isInclude:true}).operator,'contains match phrase');
});
test('ported history conversion retains disabled values and request metadata', () => {
 const item = {field:'log',operator:'all not contains match phrase',value:['one','two'],hidden_values:['secret'],disabled:true};
 const front = new ConditionOperator(item).formatApiOperatorToFront();
 assert.equal(front.relation,'AND');
 assert.equal(front.operator,'not contains match phrase');
 const api = new ConditionOperator({...front,field_type:'text'}).getRequestParam();
 assert.deepEqual(api,item);
});
