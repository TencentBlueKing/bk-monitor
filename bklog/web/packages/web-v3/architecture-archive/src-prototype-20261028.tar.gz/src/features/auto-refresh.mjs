/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

export const refreshOptions = [
  ['关闭(off)', 'off', 0], ['10s', '10s', 10000], ['30s', '30s', 30000],
  ['1m', '1m', 60000], ['5m', '5m', 300000], ['15m', '15m', 900000],
  ['30m', '30m', 1800000], ['1h', '1h', 3600000], ['2h', '2h', 7200000], ['1d', '1d', 86400000],
];

// Match the source cadence: emit at each interval, independent of request duration.
export function createRefreshTimer(refresh, timers = globalThis) {
  let timer;
  let version = 0;
  let disposed = false;
  function select(value) {
    const current = ++version;
    timers.clearTimeout(timer);
    const delay = refreshOptions.find(option => option[1] === value)?.[2] || 0;
    if (!delay || disposed) return;
    function schedule() {
      timer = timers.setTimeout(() => {
        if (disposed || current !== version) return;
        try { refresh(); } finally {
          if (!disposed && current === version) schedule();
        }
      }, delay);
    }
    schedule();
  }
  return { select, dispose() { disposed = true; version++; timers.clearTimeout(timer); } };
}
