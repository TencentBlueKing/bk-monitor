/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toSearchTimeRange, readTimePreference } from './time-range.mjs';
test('date-picker instants become API seconds without reparsing timezone or natural dates', () => {
 const range = {startDate: new Date('2026-10-27T16:00:00Z'), endDate: new Date('2026-10-28T15:59:59.999Z')};
 assert.deepEqual(toSearchTimeRange(range), {start_time:1793116800, end_time:1793203199});
 assert.throws(() => toSearchTimeRange({startDate:null,endDate:new Date()}));
 assert.throws(() => toSearchTimeRange({startDate:new Date('invalid'),endDate:new Date()}));
 assert.throws(() => toSearchTimeRange({startDate:new Date(10000),endDate:new Date(1000)}));
});
test('source preference contract is retained and corrupt preferences do not break startup', () => {
 assert.deepEqual(readTimePreference({getItem:()=> '["now-3h","now"]'}), ['now-3h','now']);
 for (const value of ['{', '["now"]', '[1,2]', 'null']) assert.deepEqual(readTimePreference({getItem:()=>value}), ['now-15m','now']);
});
