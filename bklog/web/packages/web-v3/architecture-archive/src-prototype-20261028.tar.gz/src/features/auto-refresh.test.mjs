/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createRefreshTimer } from './auto-refresh.mjs';

test('refresh selection resets cadence; off and unmount prevent future ticks', t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  let calls = 0;
  const timer = createRefreshTimer(() => calls++);
  t.mock.timers.tick(60000);
  assert.equal(calls, 0);
  timer.select('10s');
  t.mock.timers.tick(9999); assert.equal(calls, 0);
  t.mock.timers.tick(1); assert.equal(calls, 1);
  timer.select('30s');
  t.mock.timers.tick(10000); assert.equal(calls, 1);
  t.mock.timers.tick(20000); assert.equal(calls, 2);
  timer.select('off');
  t.mock.timers.tick(60000); assert.equal(calls, 2);
  timer.select('10s'); timer.dispose();
  t.mock.timers.tick(60000); assert.equal(calls, 2);
  timer.select('10s'); t.mock.timers.tick(60000); assert.equal(calls, 2);
});

test('selection or disposal during a refresh cannot resurrect an old timer', t => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  let calls = 0;
  const timer = createRefreshTimer(() => { calls++; timer.dispose(); });
  timer.select('10s'); t.mock.timers.tick(10000); t.mock.timers.tick(60000);
  assert.equal(calls, 1);
});
