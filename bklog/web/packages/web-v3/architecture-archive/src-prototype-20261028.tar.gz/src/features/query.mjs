/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

const SEARCH_NAMES = new Set(['retrieve', 'monitor-apm-log', 'monitor-trace-log']);

const FEATURES = {
  search: { kind: 'search' },
  exception: { kind: 'exception' },
  tasks: { kind: 'resource', url: '/tgpa/task_list/', query: 'biz' },
  templates: { kind: 'resource', url: '/search/index_set/list_config/', query: 'biz' },
  auth: { kind: 'resource', url: '/external_permission/', query: 'biz' },
  share: { kind: 'resource', url: '/share/get_share_params/', query: 'token' },
  dataId: { kind: 'resource', url: '/index_set/query_by_dataid/', query: 'dataId' },
  policies: { kind: 'resource', url: '/monitor/policy/', query: 'biz' },
  dashboard: { kind: 'resource', url: '/grafana/get_dashboard_directory_tree/', query: 'biz' },
  collectors: { kind: 'resource', url: '/databus/collectors/list_collectors/', query: 'collectors' },
  custom: { kind: 'resource', url: '/databus/collectors/', query: 'custom' },
  indexSets: { kind: 'resource', url: '/search/index_set/', query: 'space' },
  cleanTemplates: { kind: 'resource', url: '/databus/clean_template/', query: 'biz' },
  clean: { kind: 'resource', url: '/databus/clean/', query: 'biz' },
  rules: { kind: 'resource', url: '/desensitize/rule/', query: 'rule' },
  grok: { kind: 'resource', url: '/databus/grok/', query: 'biz' },
  repository: { kind: 'resource', url: '/databus/storage/list_repository/', query: 'biz' },
  archive: { kind: 'resource', url: '/databus/archive/', query: 'biz' },
  strategies: { kind: 'resource', url: '/log_extract/strategies/', query: 'biz' },
  extract: { kind: 'resource', url: '/log_extract/tasks/', query: 'biz' },
  clusters: { kind: 'resource', url: '/databus/storage/cluster_groups/', query: 'biz' },
  reports: { kind: 'resource', url: '/report/get_reports/', query: 'biz' },
  links: { kind: 'resource', url: '/databus/data_link/', query: 'biz' },
};

/** @returns {{kind: string, url?: string, query?: string}} */
export function resolveFeature(name) {
  if (name === 'exception' || name === 'un-authorized') return FEATURES.exception;
  if (SEARCH_NAMES.has(name)) return FEATURES.search;
  if (name === 'client-log-search' || name === 'tgpa-task' || name === 'tgpa-task-list' || name === 'clean-config') {
    return name === 'clean-config' ? FEATURES.clean : FEATURES.tasks;
  }
  if (name === 'templateManage') return FEATURES.templates;
  if (name === 'externalAuth') return FEATURES.auth;
  if (name === 'share') return FEATURES.share;
  if (name === 'data_id') return FEATURES.dataId;
  if (name === 'monitor') return FEATURES.policies;
  if (name === 'dashboard' || name === 'home' || name.startsWith('create-') || name.startsWith('import-') || name === 'default-dashboard') {
    return FEATURES.dashboard;
  }
  if (name.startsWith('collect') || name.includes('collection-item') || name === 'log-collection' || name === 'manage' || name === 'manage-collection' || name === 'collection-track') {
    return FEATURES.collectors;
  }
  if (name.includes('masking') || name.includes('desensitize')) return FEATURES.rules;
  if (name.includes('index-set') || name.startsWith('bkdata') || name.startsWith('bk-data') || name.startsWith('es-index') || name.startsWith('es-collection')) {
    return FEATURES.indexSets;
  }
  if (name.startsWith('custom-report') || name === 'sdk-track') return FEATURES.custom;
  if (name.includes('clean-template') || name === 'clean-templates') return FEATURES.cleanTemplates;
  if (name.startsWith('clean') || name === 'log-clean-list' || name === 'clean-list') return FEATURES.clean;
  if (name === 'grok-manage') return FEATURES.grok;
  if (name === 'archive-repository') return FEATURES.repository;
  if (name.startsWith('archive')) return FEATURES.archive;
  if (name.startsWith('extract-link')) return FEATURES.strategies;
  if (name.startsWith('extract') || name.includes('log-extract')) return FEATURES.extract;
  if (name === 'es-cluster-manage') return FEATURES.clusters;
  if (name === 'report-manage') return FEATURES.reports;
  if (name.includes('data-link')) return FEATURES.links;
  return { kind: 'unmapped', url: '', query: '' };
}

export function buildFeatureQuery(feature, ctx) {
  const bizId = ctx.bizId ?? '';
  const spaceUid = ctx.spaceUid ?? '';
  const params = ctx.params ?? {};
  switch (feature.query) {
    case 'collectors':
      return { bk_biz_id: bizId, have_data_id: 1, not_custom: 1 };
    case 'custom':
      return {
        bk_biz_id: bizId,
        keyword: '',
        page: 1,
        pagesize: 10,
        collector_scenario_id: 'custom',
      };
    case 'space':
      return { space_uid: spaceUid, is_group: true };
    case 'rule':
      return { space_uid: spaceUid, rule_type: 'all' };
    case 'token':
      return { token: params.linkId || '' };
    case 'dataId':
      return { bk_data_id: params.id || '' };
    case 'biz':
      return { bk_biz_id: bizId || 0 };
    default:
      return {};
  }
}

export const TIME_PRESETS = [
  { id: 'now-5m', label: '近 5 分钟', seconds: 5 * 60 },
  { id: 'now-15m', label: '近 15 分钟', seconds: 15 * 60 },
  { id: 'now-30m', label: '近 30 分钟', seconds: 30 * 60 },
  { id: 'now-1h', label: '近 1 小时', seconds: 60 * 60 },
  { id: 'now-3h', label: '近 3 小时', seconds: 3 * 60 * 60 },
  { id: 'now-6h', label: '近 6 小时', seconds: 6 * 60 * 60 },
  { id: 'now-12h', label: '近 12 小时', seconds: 12 * 60 * 60 },
  { id: 'now-24h', label: '近 24 小时', seconds: 24 * 60 * 60 },
  { id: 'now-2d', label: '近 2 天', seconds: 2 * 24 * 60 * 60 },
  { id: 'now-7d', label: '近 7 天', seconds: 7 * 24 * 60 * 60 },
];

export function timeRangeFromPreset(presetId, nowSeconds) {
  const preset = TIME_PRESETS.find(item => item.id === presetId) || TIME_PRESETS[1];
  return { id: preset.id, label: preset.label, start_time: nowSeconds - preset.seconds, end_time: nowSeconds };
}

export function histogramInterval(spanSeconds) {
  if (spanSeconds <= 30 * 60) return '1m';
  if (spanSeconds <= 6 * 60 * 60) return '5m';
  if (spanSeconds <= 24 * 60 * 60) return '30m';
  return '1h';
}

export function buildAddition(field, operator, value) {
  const text = String(value ?? '').trim();
  if (!field || !text) return null;
  return { field, operator: operator || 'contains', value: [text] };
}

export function toggleDisplayField(displayNames, fieldName) {
  if (displayNames.includes(fieldName)) return displayNames.filter(name => name !== fieldName);
  return [...displayNames, fieldName];
}

export const BUILTIN_HIDDEN_FIELDS = [
  'gseIndex',
  'gseindex',
  'iterationIndex',
  'iterationindex',
  '_iteration_idx',
  '__dist_01',
  '__dist_03',
  '__dist_05',
  '__dist_07',
  '__dist_09',
  '__ipv6__',
  '__parse_failure',
  'time',
  '__module__',
  '__set__',
  '__ipv6__',
  '__shard_key__',
  '__unique_key__',
  '__bcs_cluster_name__',
];

export function nextSortOrder(order) {
  if (order == null || order === '') return 'asc';
  if (order === 'asc') return 'desc';
  return null;
}

export function buildSortList(defaultSort, order) {
  if (!order) return [];
  const source = Array.isArray(defaultSort) && defaultSort.length ? defaultSort : [['dtEventTimeStamp', 'desc']];
  return source.map(item => [item[0], order]);
}

export function clusterView(configItems, fields) {
  const cluster = (configItems || []).find(item => item?.name === 'clustering_config');
  const hasText = (fields || []).some(field => field?.field_type === 'text');
  if (!hasText) return 'empty';
  if (!cluster?.is_active) return 'quick-open';
  return 'search';
}

export function buildFieldSidebar(fields, displayNames) {
  const visibleNames = displayNames || [];
  const visible = visibleNames.map(name => (fields || []).find(field => field.field_name === name) || { field_name: name });
  const builtIn = [];
  const optional = [];
  for (const field of fields || []) {
    if (visibleNames.includes(field.field_name)) continue;
    if (BUILTIN_HIDDEN_FIELDS.includes(field.field_name)) builtIn.push(field);
    else optional.push(field);
  }
  return { visible, optional: groupDottedFields(optional), builtIn };
}

export function colorizeLog(text) {
  const source = String(text ?? '');
  const parts = [];
  const pattern = /\b(INFO|DEBUG|WARN|WARNING|ERROR|FATAL|TRACE)\b|\b\d+(?:\.\d+)?\b/g;
  let last = 0;
  let match = pattern.exec(source);
  while (match) {
    if (match.index > last) parts.push({ text: source.slice(last, match.index), kind: 'plain' });
    parts.push({ text: match[0], kind: /^\d/.test(match[0]) ? 'number' : match[0] });
    last = match.index + match[0].length;
    match = pattern.exec(source);
  }
  if (last < source.length || !parts.length) parts.push({ text: source.slice(last), kind: 'plain' });
  return parts;
}

function groupDottedFields(fields) {
  const roots = [];
  const groups = new Map();
  for (const field of fields) {
    const dot = String(field.field_name || '').indexOf('.');
    if (dot < 0) {
      roots.push({ ...field, children: [] });
      continue;
    }
    const parentName = field.field_name.slice(0, dot);
    if (!groups.has(parentName)) {
      const node = { field_name: parentName, field_type: 'object', isGroup: true, children: [] };
      groups.set(parentName, node);
      roots.push(node);
    }
    groups.get(parentName).children.push({ ...field, children: [] });
  }
  return roots;
}

/**
 * @param {{bizId?: string|number, spaceUid?: string, keyword?: string,
 * startTime?: number, endTime?: number, size?: number, begin?: number,
 * addition?: Array<{field: string, operator: string, value: string[]}>,
 * sortList?: string[][], searchMode?: string, ipChooser?: Record<string, unknown>, timezone?: string}} [options]
 */
export function buildRetrieveQuery({
  bizId,
  spaceUid,
  keyword,
  startTime,
  endTime,
  size = 50,
  begin = 0,
  addition = [],
  sortList = [],
  searchMode = 'ui',
  timezone = 'Asia/Shanghai',
  ipChooser = {},
} = {}) {
  return {
    bk_biz_id: bizId,
    keyword: keyword == null || keyword === '' ? '*' : String(keyword),
    host_scopes: { modules: [], ips: '', target_nodes: [], target_node_type: '' },
    ip_chooser: ipChooser,
    addition,
    sort_list: sortList,
    begin,
    size,
    interval: 'auto',
    timezone,
    search_mode: searchMode,
    start_time: startTime,
    end_time: endTime,
    ...(spaceUid ? { space_uid: spaceUid } : {}),
  };
}

export function buildClusterQuery(searchQuery) {
  return {
    bk_biz_id: searchQuery.bk_biz_id,
    addition: searchQuery.addition,
    keyword: searchQuery.keyword,
    ip_chooser: searchQuery.ip_chooser,
    host_scopes: searchQuery.host_scopes,
    interval: searchQuery.interval,
    timezone: searchQuery.timezone,
    start_time: searchQuery.start_time,
    end_time: searchQuery.end_time,
    pattern_level: '05',
    year_on_year_hour: 0,
    show_new_pattern: false,
    group_by: [],
    size: 10000,
    remark_config: 'all',
    owner_config: 'all',
    owners: [],
  };
}

export function defaultTimeRange(nowSeconds) {
  const range = timeRangeFromPreset('now-15m', nowSeconds);
  return { start_time: range.start_time, end_time: range.end_time };
}

export function indexSetLabel(node) {
  const tableIds = (node?.indices ?? []).map(entry => entry.result_table_id).filter(Boolean);
  const suffix = !tableIds.length
    ? ' ()'
    : tableIds.length <= 3
      ? ` (${tableIds.join(';')})`
      : ` (${tableIds.slice(0, 3).join(';')}+${tableIds.length - 3})`;
  return `${node?.index_set_name || ''}${suffix}`;
}

export function flattenIndexSets(nodes, acc = []) {
  for (const node of nodes || []) {
    if (node?.index_set_id != null && node.index_set_name) {
      acc.push({
        index_set_id: String(node.index_set_id),
        index_set_name: node.index_set_name,
        label: indexSetLabel(node),
      });
    }
    if (node?.children?.length) flattenIndexSets(node.children, acc);
  }
  return acc;
}

export function toRows(data) {
  const raw = Array.isArray(data) ? data : data?.list;
  if (Array.isArray(raw)) {
    if (raw.some(item => Array.isArray(item?.children))) return flattenTree(raw);
    return raw.filter(item => item && typeof item === 'object');
  }
  if (data && typeof data === 'object') return [data];
  return [];
}

function flattenTree(nodes, acc = []) {
  for (const node of nodes || []) {
    if (!node || typeof node !== 'object') continue;
    const { children, ...rest } = node;
    if (Object.keys(rest).length) acc.push(rest);
    if (Array.isArray(children)) flattenTree(children, acc);
  }
  return acc;
}

// Keep page highlighting as text segments so log content never becomes HTML.
export function highlightLog(text, keywords, { caseSensitive = false, regex = false, wholeWord = false } = {}) {
  const ranges = [];
  for (const keyword of keywords) {
    if (!keyword) continue;
    let pattern = regex ? keyword : keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (wholeWord) pattern = `\\b(?:${pattern})\\b`;
    let expression;
    try { expression = new RegExp(pattern, caseSensitive ? 'g' : 'gi'); } catch { continue; }
    for (const match of text.matchAll(expression)) {
      if (match[0].length) ranges.push([match.index, match.index + match[0].length]);
    }
  }
  ranges.sort((a, b) => a[0] - b[0]);
  const merged = [];
  for (const range of ranges) {
    const last = merged.at(-1);
    if (last && range[0] <= last[1]) last[1] = Math.max(last[1], range[1]);
    else merged.push([...range]);
  }
  const parts = [];
  let cursor = 0;
  for (const [start, end] of merged) {
    if (start > cursor) parts.push({ text: text.slice(cursor, start), highlighted: false });
    parts.push({ text: text.slice(start, end), highlighted: true });
    cursor = end;
  }
  if (cursor < text.length) parts.push({ text: text.slice(cursor), highlighted: false });
  return parts;
}
