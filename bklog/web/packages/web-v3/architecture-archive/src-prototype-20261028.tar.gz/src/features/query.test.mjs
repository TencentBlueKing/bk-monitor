/*
 * Tencent is pleased to support the open source community by making
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) available.
 *
 * Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * 蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
 *
 * License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
 *
 * ---------------------------------------------------
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
 * to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of
 * the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

import assert from 'node:assert/strict';
import { test } from 'node:test';

import routes from '../router/legacy-routes.json' with { type: 'json' };
import {
  buildAddition,
  buildClusterQuery,
  buildFeatureQuery,
  buildFieldSidebar,
  buildRetrieveQuery,
  buildSortList,
  clusterView,
  colorizeLog,
  defaultTimeRange,
  flattenIndexSets,
  highlightLog,
  nextSortOrder,
  resolveFeature,
  toggleDisplayField,
  toRows,
} from './query.mjs';

test('every legacy route maps to a Vue 3 feature', () => {
  const unmapped = routes.filter(route => resolveFeature(route.name).kind === 'unmapped').map(route => route.name);
  assert.deepEqual(unmapped, []);
  assert.equal(resolveFeature('retrieve').kind, 'search');
  assert.equal(routes.find(route => route.name === 'collection-item-list').path, '/manage/log-collection/collection-item/list');
});

test('retrieve query keeps the Vue 2 search body', () => {
  const query = buildRetrieveQuery({
    bizId: '5000140',
    spaceUid: 'bkcc__5000140',
    keyword: '',
    startTime: 100,
    endTime: 200,
  });
  assert.equal(query.keyword, '*');
  assert.equal(query.search_mode, 'ui');
  assert.equal(query.interval, 'auto');
  assert.equal(query.timezone, 'Asia/Shanghai');
  assert.deepEqual(query.addition, []);
  assert.equal(query.space_uid, 'bkcc__5000140');
  assert.deepEqual(defaultTimeRange(1000), { start_time: 100, end_time: 1000 });
  assert.deepEqual(buildAddition('log', 'contains', 'tornado'), {
    field: 'log',
    operator: 'contains',
    value: ['tornado'],
  });
  assert.deepEqual(toggleDisplayField(['log'], 'serverIp'), ['log', 'serverIp']);
  assert.equal(buildClusterQuery(query).pattern_level, '05');
  assert.deepEqual(buildSortList([['dtEventTimeStamp', 'desc'], ['gseIndex', 'desc']], 'asc'), [
    ['dtEventTimeStamp', 'asc'],
    ['gseIndex', 'asc'],
  ]);
  assert.equal(nextSortOrder(null), 'asc');
  assert.equal(nextSortOrder('desc'), null);
  assert.equal(clusterView([{ name: 'clustering_config', is_active: false }], [{ field_type: 'text' }]), 'quick-open');
  assert.equal(clusterView([{ name: 'clustering_config', is_active: false }], [{ field_type: 'keyword' }]), 'empty');
  const sidebar = buildFieldSidebar([
    { field_name: 'log', field_type: 'text' },
    { field_name: '__ext.container_id', field_type: 'keyword' },
    { field_name: 'path', field_type: 'keyword' },
    { field_name: 'time', field_type: 'date' },
  ], ['log']);
  assert.equal(sidebar.optional[0].field_name, '__ext');
  assert.equal(sidebar.optional[0].children.length, 1);
  assert.equal(sidebar.optional[1].field_name, 'path');
  assert.equal(sidebar.builtIn[0].field_name, 'time');
  assert.equal(colorizeLog('INFO 200').find(part => part.kind === 'INFO').text, 'INFO');
});

test('collector list query matches the collection page', () => {
  const feature = resolveFeature('collection-item-list');
  assert.equal(feature.url, '/databus/collectors/list_collectors/');
  assert.deepEqual(buildFeatureQuery(feature, { bizId: 7 }), {
    bk_biz_id: 7,
    have_data_id: 1,
    not_custom: 1,
  });
});

test('index set groups flatten to named sets', () => {
  const rows = flattenIndexSets([
    { index_set_id: 1, index_set_name: 'parent', children: [{ index_set_id: 2, index_set_name: 'child', children: [] }] },
  ]);
  assert.equal(rows[0].index_set_name, 'parent');
  assert.equal(rows[1].index_set_name, 'child');
  assert.equal(rows[0].label, 'parent ()');
  assert.equal(toRows({ list: [{ id: 1 }] }).length, 1);
});

test('highlighting preserves log text, literal punctuation and overlapping matches', () => {
  const text = '<script> a.b INFO information';
  const parts = highlightLog(text, ['a.b', 'INFO', 'information']);
  assert.equal(parts.map(part => part.text).join(''), text);
  assert.deepEqual(parts.filter(part => part.highlighted).map(part => part.text), ['a.b', 'INFO', 'information']);
  assert.deepEqual(highlightLog('ababa', ['aba', 'bab']).filter(part => part.highlighted).map(part => part.text), ['abab']);
  assert.equal(highlightLog('INFO information', ['info'], { wholeWord: true }).filter(part => part.highlighted).length, 1);
  assert.equal(highlightLog('INFO', ['info'], { caseSensitive: true }).filter(part => part.highlighted).length, 0);
  assert.equal(highlightLog('abc', ['['], { regex: true }).map(part => part.text).join(''), 'abc');
  assert.equal(highlightLog('abc', ['^'], { regex: true }).map(part => part.text).join(''), 'abc');
});

test('restored query keeps SQL mode, chooser and API condition operators', () => {
  const addition = [{ field: 'log', operator: 'contains match phrase', value: ['INFO'] }];
  const query = buildRetrieveQuery({ searchMode: 'sql', ipChooser: { ips: ['127.0.0.1'] }, addition });
  assert.equal(query.search_mode, 'sql');
  assert.deepEqual(query.ip_chooser, { ips: ['127.0.0.1'] });
  assert.deepEqual(query.addition, addition);
});
