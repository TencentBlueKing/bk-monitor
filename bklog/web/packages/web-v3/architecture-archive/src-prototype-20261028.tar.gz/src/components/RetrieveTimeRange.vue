<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
// Vue3 port of src/components/time-range/time-range.tsx.
// Date parsing, calendar, shortcuts, timezone and format UI remain in the shared BlueKing component.
import DatePicker, { type DateValue } from '@blueking/date-picker';
import '@blueking/date-picker/vue3/vue3.css';
const props = withDefaults(defineProps<{
  modelValue: DateValue;
  timezone: string;
  format: string;
  maxDuration?: number;
  needTimezone?: boolean;
}>(), { maxDuration: 180 * 24 * 60 * 60 * 1000, needTimezone: true });
const emit = defineEmits<{
  'update:modelValue': [DateValue]; change: [DateValue];
  'update:timezone': [string]; 'timezone-change': [string];
  'update:format': [string]; 'format-change': [string];
}>();
function change(value: DateValue | undefined) {
  if (!value) return;
  if (value.every(item => typeof item === 'string')) localStorage.setItem('SEARCH_DEFAULT_TIME', JSON.stringify(value));
  emit('update:modelValue', value);
  emit('change', value);
}
function formatChange(format: string) {
  localStorage.setItem('SEARCH_DEFAULT_TIME_FORMAT', format);
  emit('update:format', format);
  emit('format-change', format);
}
function timezoneChange(timezone: string) {
  if (!timezone) return;
  emit('update:timezone', timezone);
  emit('timezone-change', timezone);
}
</script>
<template>
 <div class="retrieve-time-range">
  <DatePicker behavior="simplicity" :model-value="props.modelValue" :need-timezone="needTimezone" :enable-format-click="true" :timezone="timezone" :format="format" :max-duration="maxDuration" @update:model-value="change" @update:format="formatChange" @update:timezone="timezoneChange" />
 </div>
</template>
<style scoped>
.retrieve-time-range { display: inline-flex; flex-shrink: 0; }
</style>
