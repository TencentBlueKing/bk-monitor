<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { Drawer, Input, Button } from 'tdesign-vue-next';
const props = withDefaults(defineProps<{ visible: boolean; row: Record<string, unknown> | null; filterFields?: string[] }>(), { filterFields: () => [] });
const emit = defineEmits<{ 'update:visible': [boolean]; filter: [string, unknown] }>();
const query = ref('');
const mode = ref('table');
const copyMessage = ref('');
watch(() => props.row, () => { query.value = ''; copyMessage.value = ''; });
const entries = computed(() => Object.entries(props.row || {}).filter(([key]) => key !== '__data_label' && key.toLowerCase().includes(query.value.toLowerCase())));
function text(value: unknown) { return typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value ?? ''); }
async function copy() {
 try { await navigator.clipboard.writeText(JSON.stringify(props.row, null, 2)); copyMessage.value = '已复制'; }
 catch { copyMessage.value = '复制失败，请手动复制'; }
}
</script>
<template>
 <Drawer :visible="visible" header="日志详情" size="65%" :footer="false" @update:visible="value => emit('update:visible', value)">
  <div class="detail-meta"><span>IP：{{ row?.serverIp || '/' }}</span><span>日志路径：{{ row?.path || '/' }}</span></div>
  <div class="detail-tools"><Input v-model="query" placeholder="搜索字段名" clearable /><Button :variant="mode === 'table' ? 'base' : 'outline'" @click="mode = 'table'">表格</Button><Button :variant="mode === 'json' ? 'base' : 'outline'" @click="mode = 'json'">JSON</Button><Button variant="text" @click="copy">复制</Button><span role="status">{{ copyMessage }}</span></div>
  <pre v-if="mode === 'json'" class="detail-json">{{ JSON.stringify(row, null, 2) }}</pre>
  <dl v-else class="detail-fields"><template v-for="[key, value] in entries" :key="key"><dt>{{ key }}</dt><dd><pre>{{ text(value) }}</pre><Button v-if="filterFields.includes(key)" variant="text" size="small" @click="emit('filter', key, value)">添加到检索条件</Button></dd></template></dl>
 </Drawer>
</template>
<style scoped>
.detail-meta { display: flex; gap: 24px; padding-bottom: 16px; color: #63656e; }
.detail-tools { display: flex; align-items: center; gap: 8px; margin-bottom: 16px; }
.detail-tools .t-input__wrap { max-width: 260px; }
.detail-fields { display: grid; grid-template-columns: 180px minmax(0,1fr); font: 12px/20px monospace; }
.detail-fields dt, .detail-fields dd { padding: 8px; margin: 0; border-bottom: 1px solid #dcdee5; overflow-wrap: anywhere; }
.detail-fields dt { background: #f5f7fa; }
.detail-fields pre, .detail-json { white-space: pre-wrap; overflow-wrap: anywhere; margin: 0; }
</style>
