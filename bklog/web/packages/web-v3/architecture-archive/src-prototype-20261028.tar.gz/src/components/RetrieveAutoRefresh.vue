<!--
  Tencent is pleased to support the open source community by making
  蓝鲸智云PaaS平台 (BlueKing PaaS) available.
  Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
  蓝鲸智云PaaS平台 (BlueKing PaaS) is licensed under the MIT License.
  License for 蓝鲸智云PaaS平台 (BlueKing PaaS):
  ---------------------------------------------------
  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
  documentation files (the "Software"), to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so, subject to the following conditions:
  The above copyright notice and this permission notice shall be included in all copies or substantial portions of
  the Software.
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
  THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
  IN THE SOFTWARE.
-->

<script setup lang="ts">
import { onBeforeUnmount, ref } from 'vue';
import { Popup } from 'tdesign-vue-next';
import { createRefreshTimer, refreshOptions } from '../features/auto-refresh.mjs';

const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const selected = ref('off');
const timer = createRefreshTimer(() => emit('refresh'));
function select(value: string) {
  selected.value = value;
  visible.value = false;
  timer.select(value);
}
onBeforeUnmount(() => timer.dispose());
</script>

<template>
  <Popup v-model:visible="visible" trigger="click" placement="bottom" :show-arrow="false" overlay-class-name="retrieve-refresh-overlay">
    <button class="retrieve-refresh-trigger" type="button" aria-label="自动刷新设置" :aria-expanded="visible" title="自动刷新设置">
      <span aria-hidden="true">↻</span><span>{{ selected }}</span>
    </button>
    <template #content>
      <ul class="retrieve-refresh-options" aria-label="自动刷新周期">
        <li v-for="[label, value] in refreshOptions" :key="value">
          <button type="button" :aria-pressed="selected === value" @click="select(String(value))">{{ label }}</button>
        </li>
      </ul>
    </template>
  </Popup>
</template>

<style>
.retrieve-refresh-trigger { display: flex; align-items: center; justify-content: center; gap: 4px; height: 20px; min-width: 44px; margin: 0 2px; padding: 0 4px; border: 0; border-radius: 2px; background: transparent; color: #63656e; font-size: 12px; line-height: 20px; cursor: pointer; }
.retrieve-refresh-trigger:hover, .retrieve-refresh-trigger[aria-expanded="true"] { color: #3a84ff; background: #e1ecff; }
.retrieve-refresh-trigger > span:first-child { font-size: 16px; }
.retrieve-refresh-overlay .t-popup__content { padding: 0; }
.retrieve-refresh-options { width: 80px; height: 174px; padding: 4px 0; margin: 0; overflow-y: auto; list-style: none; }
.retrieve-refresh-options button { display: block; width: 100%; height: 32px; padding: 0 12px; border: 0; background: transparent; color: #63656e; font-size: 12px; line-height: 32px; text-align: left; cursor: pointer; }
.retrieve-refresh-options button:hover, .retrieve-refresh-options button:focus-visible { color: #3a84ff; background: #e1ecff; }
</style>
