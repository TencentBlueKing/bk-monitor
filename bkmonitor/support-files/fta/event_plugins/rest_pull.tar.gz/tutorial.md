#### 1. 根据配置自动拉取符合条件的restapi告警
```python
    import requests
    params = {
        'begin_time__gte': "2022-07-01 09:00:00",
        'begin_time__lte': "2022-07-01 09:10:00",
    }
    
    r = requests.post('{{plugin.ingest_config.url}}', data=params)
    resp = r.json()
```
####2.返回数据格式
```json
    {
    "result": true, 
    "message": "", 
    "data":[
        {"ip": "10.0.0.1",
        "source_id": "123456",
        "source_time": "2022-07-01 16:50:00",
        "alarm_type": "default",
        "alarm_content": "FAILURE for production/HTTP on machine 10.0.0.1"
        },
        {"ip": "10.0.0.2",
        "source_id": "123457",
        "source_time": "2022-07-01 16:50:00",
        "alarm_type": "default",
        "alarm_content": "FAILURE for production/HTTP on machine 10.0.0.2"
        }
    ]}
```