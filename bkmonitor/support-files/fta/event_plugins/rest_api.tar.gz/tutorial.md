1. 使用 curl 上报示例

    ```shell
    curl -X POST -d '{
        "ip": "10.0.0.1", 
        "source_id": "123456",    
        "source_time": "2017-04-06 16:50:00+08:00",   
        "alarm_type": "api_default",
        "alarm_content": "FAILURE for production/HTTP on machine 10.0.0.1", 
        "alarm_context": {"key1":"value1","key2":"value2"}, 
        "description": "avg(usage) > 90%, 当前值 99%",
        "target_type": "HOST",
        "category": "os",
        "severity": 1,
        "bk_biz_id": 2,
    }' -H "X-Bk-Fta-Token: {{ plugin.token }}" "{{ plugin.ingest_config.push_url }}"
    ```
